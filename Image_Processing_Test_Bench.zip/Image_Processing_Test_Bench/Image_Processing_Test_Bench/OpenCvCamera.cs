﻿using OpenCvSharp;
using OpenCvSharp.Extensions;

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tools
{
    public class OpenCvCamera
    {
        public int camera_index;
        public int max_camera_count=0;
        public int min_camera_count=0;

        VideoCapture capture;
        OpenCvSharp.Mat frame;
        Bitmap image;
        Thread camera;
        bool IsOpened = false;
        bool isCameraRunning = false;
        bool exit = false;

        PictureBox pb;
        public Bitmap Captured_Image;
        public bool Take_snapshot = false;
  
        public OpenCvCamera(PictureBox pb1)
        {
            pb = new PictureBox();
            pb = pb1;
            camera = new Thread(new ThreadStart(CaptureCameraCallback));
        }

        private void CaptureCameraCallback()
        {
            while (!exit)
            {
                if (isCameraRunning)
                {
                    try
                    {
                        capture.Read(frame);
                        image = BitmapConverter.ToBitmap(frame);
                        if (Take_snapshot)
                        {
                            Captured_Image = image;
                            Take_snapshot = false;
                        }

                        if (pb.Image != null)
                        {
                            pb.Image.Dispose();
                        }
                        pb.Image = image;
                    }
                    catch (Exception ex)
                    {
                        string s = ex.ToString();
                    }

                }
            }
           
        }

        public Image Get_Still_Image()
        {
            Bitmap img=null;
            Mat fr = new OpenCvSharp.Mat();
            VideoCapture cap = new VideoCapture(camera_index);
            cap.Open(camera_index);

            if (cap.IsOpened())
            {
                cap.Read(fr);
                img = BitmapConverter.ToBitmap(fr);
            }           
            cap.Dispose();
            fr.Dispose();
            return img;
        }
    
    public void open()
        {
            if (IsOpened) return;

            frame = new OpenCvSharp.Mat();
            capture = new VideoCapture(camera_index);
            capture.Open(camera_index);

            if (capture.IsOpened())
            {
                IsOpened = true;
                exit=false;
                isCameraRunning = true;
                camera.Start();
            }
            else
            {
                IsOpened = false;
                frame.Dispose();
                capture.Dispose();
            }            
        }

        public void close()
        {
            if(capture.IsDisposed) return;

            try
            {
                capture.Dispose();
                frame.Dispose();
            }
            catch(Exception ex)
            {
                string s = ex.ToString();
            }
        }

        public void start()
        {
            isCameraRunning = true;
        }

        public void stop()
        {
            isCameraRunning = false;
        }

        public void next()
        {
            if(camera_index<max_camera_count)
            {
                camera_index++;
            }
            else
            {
                camera_index = min_camera_count;             
            }
        }

        public void previous()
        {
            if (camera_index>min_camera_count )
            {
                camera_index--;
            }
            else
            {
                camera_index =max_camera_count;
            }
        }












    }// class
    
}// NameSpace
