﻿using OpenCvSharp;
using OpenCvSharp.Extensions;

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tools
{
    public class OpenCvCamera_NonThreaded
    {
        public int camera_index=1;
        public int max_camera_count=1;
        public int min_camera_count=0;

        VideoCapture capture;
        Mat frame;
        public bool IsOpened = false;

        public enum command
        {
            open,
            close,
            next,
            previous,
            get_image
        };

        public OpenCvCamera_NonThreaded()
        {

        }

        //public Image Execute_Command(string cmd)
        //{
        //    switch(cmd)
        //        {
        //        case "open":
        //            open();
        //            break;
        //            /////////////
        //        case "close":
        //            close();
        //            break;
        //        /////////////
        //        case "next":

        //            break;
        //        ////////////
        //        case "previous":

        //            break;
        //        ////////////
        //        case "get_image":

        //            break;
        //        /////////////
        //        default:

        //            break;

        //         }


        //    return null;
        //}

        public void open()
        {
            if (IsOpened) return;

            capture = new VideoCapture(camera_index);
            capture.Open(camera_index);

            if (capture.IsOpened())
            {
                frame = new Mat();
                IsOpened = true;
            }
            else
            {
                IsOpened = false;
                capture.Dispose();
            }
        }

        public void close()
        {
            if(capture==null) return;

            if (!capture.IsDisposed)
            {
                capture.Dispose();
            }
            if(!frame.IsDisposed)
            {
                frame.Dispose();
            }
            IsOpened = false;
        }

        public Image Get_Image()
        {
            Bitmap img = null;

            if (capture.IsDisposed) return null;
           
            if (capture.IsOpened())
            {
                capture.Read(frame);
                img = BitmapConverter.ToBitmap(frame);
                return img;
            }
            return null;
        }

        public Image Get_next_Camera_Image()
        {
            close();

            if (camera_index<max_camera_count)
            {
                camera_index++;
            }
            else
            {
                camera_index = min_camera_count;             
            }        
            open();
            return Get_Image();
        }

        public void previous()
        {
            close();

            if (camera_index>min_camera_count )
            {
                camera_index--;
            }
            else
            {
                camera_index =max_camera_count;
            }
        }












    }// class
    
}// NameSpace
