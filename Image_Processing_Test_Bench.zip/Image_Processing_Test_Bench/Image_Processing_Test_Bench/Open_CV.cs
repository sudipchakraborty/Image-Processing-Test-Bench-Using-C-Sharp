﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenCvSharp;

// Go to Tools> NuGet Package Manager> Manage NuGet Packages for Solutions> Browse Tab> type: OpenCVSharp> ckick install
// "OpenCVSharp" by OpenCVSharp
// "OpenCvSharp3-AnyCPU" by Shimat


namespace Tools
{
    class Open_CV
    {
        VideoCapture cap = new VideoCapture(0);
        double scalingFactor = 1.0;

        //# Define 'blue' range in HSV colorspace 
        Scalar lower = new Scalar(80, 40, 40);
        Scalar upper = new Scalar(120, 255, 255);

        public Open_CV()
        {

        }

        public void webcam()
        {          
            var frame = GetFrame(cap, scalingFactor);
            //# Convert the HSV colorspace 
            OpenCvSharp.Mat hsvFrame = new OpenCvSharp.Mat();
            Cv2.CvtColor(frame, hsvFrame, ColorConversionCodes.BGR2HSV);

            // # Threshold the HSV image to get only blue color 
            OpenCvSharp.Mat mask = new OpenCvSharp.Mat();
            Cv2.InRange(hsvFrame, lower, upper, mask);

            // # Bitwise-AND mask and original image 
            OpenCvSharp.Mat res = new OpenCvSharp.Mat();
            Cv2.BitwiseAnd(frame, frame, res, mask: mask);
            Cv2.MedianBlur(res, res, ksize: 5);

            Cv2.ImShow("Original image", frame);
            Cv2.ImShow("Color Detector", res); 
        }
        //_____________________________________________________________________________________________________
        private static OpenCvSharp.Mat GetFrame(VideoCapture cap, double scalingFactor)
        {
            // Capture the frame from video capture object 
            OpenCvSharp.Mat frame = new OpenCvSharp.Mat();
            bool ret = cap.Read(frame);
            // Resize the input frame
            Cv2.Resize(frame, frame, new Size(), fx: scalingFactor, fy: scalingFactor, interpolation: InterpolationFlags.Area);
            return frame;
        }
        //_____________________________________________________________________________________________________

        




        public void erode_Dilate()
        {
            OpenCvSharp.Mat image = Cv2.ImRead(@"d:\morphology.png");
            OpenCvSharp.Mat kernel = Cv2.GetStructuringElement(MorphShapes.Rect, new Size(3, 3));

            //Mat kernel = Mat.Ones(new Size(3, 3), MatType.CV_8U);
            OpenCvSharp.Mat erosion3x3 = new OpenCvSharp.Mat();
            //Cv2.Erode(image, erosion3x3, kernel, iterations: 1);
            Cv2.ImShow("original", image);
            //Cv2.ImShow("erodedOnce", erosion3x3);
            Cv2.Erode(image, erosion3x3, kernel, iterations: 5);
            Cv2.ImShow("eroded5times", erosion3x3);

            OpenCvSharp.Mat dilation3x3 = new OpenCvSharp.Mat();
            Cv2.Dilate(erosion3x3, dilation3x3, kernel, iterations: 2);
            Cv2.ImShow("dilation2times", dilation3x3);

            //Mat image = Cv2.ImRead(@"..\..\..\images\morphology.png");
            //Cv2.ImShow("input", image);
            //Mat kernel = Cv2.GetStructuringElement(MorphShapes.Rect, new Size(3, 3));
            //Mat opening = new Mat();
            //Cv2.MorphologyEx(image, opening, MorphTypes.Open, kernel,iterations:3);
            //Cv2.ImShow("opening", opening);

            //Mat closing = new Mat();
            //Cv2.MorphologyEx(image, closing, MorphTypes.Close, kernel,iterations:3);
            //Cv2.ImShow("closing", closing);

            //Mat gradient = new Mat();
            //Cv2.MorphologyEx(image, gradient, MorphTypes.Gradient, kernel,iterations:3);
            //Cv2.ImShow("gradient", gradient);
        }
        //_____________________________________________________________________________________________________
        public void missing_pizza()
        {
            //Mat img  = Cv2.ImRead(@"..\..\..\images\pizzas.png");
            OpenCvSharp.Mat img = Cv2.ImRead(@"d:\\pizzas.png");
          //  var contours = GetAllContours(img);
            double factor = 0.01;
            //  Cv2.DrawContours(img, contours, -1, new Scalar(0, 0, 0), thickness: 2);
            //foreach (Point[] contour in contours)
            //{
            //    double epsilon = factor * Cv2.ArcLength(contour, true);
            //    var contourNew = Cv2.ApproxPolyDP(contour, epsilon, true);
            //    //Extract convex hull from the contour
            //    bool convex = Cv2.IsContourConvex(contourNew);
            //    //int[] indices = Cv2.ConvexHullIndices(contourNew);
            //    //// int[] hull =  Cv2.ConvexHull(new Mat { contour }, false,false);
            //    //// Extract convexity defects from the above hull
            //    ////Being a convexity defect the cavities in the hull segments
            //    //var defect = Cv2.ConvexityDefects(contourNew, indices);

            //    if (convex)
            //    {
            //        continue;
            //    }
            //    Cv2.DrawContours(img, new Point[][] { contour}, 0, new Scalar(0, 0, 0), thickness: 2);
            //}
            //Cv2.ImShow("img", img);         
        }
        //_____________________________________________________________________________________________________
      
        public void filter_canny()
        {
            string path = "D:\\road.jpg";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);

            Cv2.CvtColor(image, image, ColorConversionCodes.BGR2GRAY);
            OpenCvSharp.Mat edgesL2 = new OpenCvSharp.Mat();


            OpenCvSharp.Mat edgesL1 = new OpenCvSharp.Mat();
            Cv2.Canny(image, edgesL2, 125, 350, 3, true);
            Cv2.Canny(image, edgesL1, 125, 350, 3, false);           

            Cv2.ImShow("original", image);
            Cv2.ImShow("edgesL1", edgesL1);
            Cv2.ImShow("edgesL2", edgesL2);          
        }
        //___________________________________________________________________________________________________________________
        public void filter_sobel64()
        {
            int ksize = 3;

            string path = "D:\\castle.jpg";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);

            Cv2.CvtColor(image, image, ColorConversionCodes.BGR2GRAY);
            Cv2.Resize(image, image, new Size(), 0.5, 0.5, InterpolationFlags.Area);

            OpenCvSharp.Mat sobelX64 = new OpenCvSharp.Mat(image.Rows, image.Cols, MatType.CV_64F);
            OpenCvSharp.Mat sobelY64 = new OpenCvSharp.Mat(image.Rows, image.Cols, MatType.CV_64F);

            Cv2.Sobel(image, sobelX64, MatType.CV_64F, 1, 0, ksize);
            Cv2.Sobel(image, sobelY64, MatType.CV_64F, 0, 1, ksize);

            OpenCvSharp.Mat sobelXY64 = new OpenCvSharp.Mat();
            OpenCvSharp.Mat sobelXY = new OpenCvSharp.Mat();


            Cv2.ConvertScaleAbs(sobelX64, sobelX64);
            Cv2.ConvertScaleAbs(sobelY64, sobelY64);
            Cv2.Add(sobelX64, sobelY64, sobelXY64);


            Cv2.ImShow("original", image);
            Cv2.ImShow("Sobelx64", sobelX64);

            Cv2.ImShow("SobelXY", sobelY64);
            sobelXY64.ConvertTo(sobelXY, MatType.CV_8U);

            Cv2.ImShow("sobelXYBoth", sobelXY);
        }
        //___________________________________________________________________________________________________________________
        public void filter_sobel()
        {
            int ksize = 3;

            string path = "D:\\castle.jpg";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);

            Cv2.CvtColor(image, image, ColorConversionCodes.BGR2GRAY);
            Cv2.Resize(image, image, new Size(),0.5, 0.5,InterpolationFlags.Area);

            OpenCvSharp.Mat sobelX = new OpenCvSharp.Mat(image.Rows, image.Cols, MatType.CV_8U);
            OpenCvSharp.Mat sobelY = new OpenCvSharp.Mat(image.Rows, image.Cols, MatType.CV_8U);

            Cv2.Sobel(image, sobelX, MatType.CV_8U, 1, 0, ksize);
            Cv2.Sobel(image, sobelY, MatType.CV_8U, 0, 1, ksize);

            OpenCvSharp.Mat sobelXY = new OpenCvSharp.Mat();
            Cv2.Add(sobelX, sobelY, sobelXY);
      
            Cv2.ImShow("original", image);
            Cv2.ImShow("sobelx", sobelX);
            Cv2.ImShow("sobely", sobelY);

            Cv2.ImShow("sobelxy", sobelXY);
        }
        //___________________________________________________________________________________________________________________
        public void filter_low_pass_using_Blur_Gaussian()
        { 
            string path = "D:\\castle.jpg";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);

            //var kernel3x3 = OpenCvSharp.Mat.Ones(new Size(3, 3), MatType.CV_32F) / 9;
            //var kernel5x5 = OpenCvSharp.Mat.Ones(new Size(5, 5), MatType.CV_32F) / 25;
            //OpenCvSharp.Mat result3x3 = new OpenCvSharp.Mat();
            //OpenCvSharp.Mat result5x5 = new OpenCvSharp.Mat();
            //OpenCvSharp.Mat container = new OpenCvSharp.Mat(image.Height, 3 * (image.Width) + 20 * 2, MatType.CV_8UC3);


            OpenCvSharp.Mat result5x5Gaus = new OpenCvSharp.Mat();
            OpenCvSharp.Mat result5x5Blur = new OpenCvSharp.Mat();
            OpenCvSharp.Mat container1 = new OpenCvSharp.Mat(image.Height, 3 * (image.Width) + 20 * 2, MatType.CV_8UC3);

            Cv2.Blur(image, result5x5Blur, new Size(5, 5)); // size of the filter
            container1[new Rect(new Point(0, 0), new Size(image.Width, image.Height))] = image;
            container1[new Rect(new Point(image.Width + 20, 0), new Size(image.Width, image.Height))] = result5x5Blur;


            Cv2.GaussianBlur(image, result5x5Gaus, new Size(5, 5), 1.5, 1.5); // last parameter controls the shape of the Gaussian
            container1[new Rect(new Point(2 * image.Width + 40, 0), new Size(image.Width, image.Height))] = result5x5Gaus;
            Cv2.ImShow("castle original and blurred and gaussian", container1);
        }
        //___________________________________________________________________________________________________________________
        public void filter_low_pass_using_Blur()
        {
            string path = "D:\\castle.jpg";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);

            OpenCvSharp.Mat result5x5Blur = new OpenCvSharp.Mat();
            OpenCvSharp.Mat container1 = new OpenCvSharp.Mat(image.Height, 3 * (image.Width) + 20 * 2, MatType.CV_8UC3);

            Cv2.Blur(image, result5x5Blur, new Size(5, 5)); // size of the filter
            container1[new Rect(new Point(0, 0), new Size(image.Width, image.Height))] = image;
            container1[new Rect(new Point(image.Width + 20, 0), new Size(image.Width, image.Height))] = result5x5Blur;

            Cv2.ImShow("castle original and blurred and gaussian", container1);
        }
        //___________________________________________________________________________________________________________________
        public void filter_low_pass()
        {
            string path = "D:\\castle.jpg";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("original", image);

            var kernel3x3 = OpenCvSharp.Mat.Ones(new Size(3, 3), MatType.CV_32F) / 9;
            var kernel5x5 = OpenCvSharp.Mat.Ones(new Size(5, 5), MatType.CV_32F) / 25;

            OpenCvSharp.Mat result3x3 = new OpenCvSharp.Mat();
            OpenCvSharp.Mat result5x5 = new OpenCvSharp.Mat();
            OpenCvSharp.Mat container = new OpenCvSharp.Mat(image.Height, 3 * (image.Width) + 20 * 2, MatType.CV_8UC3);

            Cv2.Filter2D(image, result3x3, -1, kernel3x3);
            Cv2.Filter2D(image, result5x5, -1, kernel5x5);

            container[new Rect(new Point(0, 0), new Size(image.Width, image.Height))] = image;
            container[new Rect(new Point(image.Width + 20, 0), new Size(image.Width, image.Height))] = result3x3;
            container[new Rect(new Point(2* image.Width+40, 0), new Size(image.Width, image.Height))] = result5x5;

            Cv2.ImShow("Side by side", container);           
        }
        //___________________________________________________________________________________________________________________
        public void histogram() 
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("original", image);

            OpenCvSharp.Mat histogram = ComputeHistogram(image);
            PlotHistogram(histogram);
        }
        //___________________________________________________________________________________________________________________
        static OpenCvSharp.Mat ComputeHistogram(OpenCvSharp.Mat image)
        {
            OpenCvSharp.Mat histogram = new OpenCvSharp.Mat();

            Rangef[] ranges = { new Rangef(0, 256), };
            int[] channels = new int[] { 0 };
            int[] histSize = new int[] { 256 };

            Cv2.CalcHist(new OpenCvSharp.Mat[] { image }, channels, null, histogram, 1, histSize, ranges);
            return histogram;
        }
        //___________________________________________________________________________________________________________________
        static void PlotHistogram(OpenCvSharp.Mat histogram)
        {
            int plotWidth = 1024, plotHeight = 400;
            int binWidth = (plotWidth / histogram.Rows);
            OpenCvSharp.Mat canvas = new OpenCvSharp.Mat(plotHeight, plotWidth, MatType.CV_8UC3, new Scalar(0, 0, 0));
            Cv2.Normalize(histogram, histogram, 0, plotHeight, NormTypes.MinMax);

            for(int rows=1; rows<histogram.Rows;++rows)
            {
                Cv2.Line(canvas,
                new Point((binWidth*(rows-1)),(plotHeight-(float)(histogram.At<float>(rows-1,0)))),
                new Point(binWidth * rows,(plotHeight - (float)(histogram.At<float>(rows, 0)))),
                new Scalar(125,125,125),2);
                    

            }
            Cv2.ImShow("Histogram", canvas);

        }
        //___________________________________________________________________________________________________________________
        public void threshold_otsu()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("original", image);

            OpenCvSharp.Mat grayscaled = new OpenCvSharp.Mat();
            Cv2.CvtColor(image, grayscaled, ColorConversionCodes.BGR2GRAY);
            Cv2.ImShow("grayscaled", grayscaled);

            OpenCvSharp.Mat otsu = new OpenCvSharp.Mat();
            Cv2.Threshold(grayscaled, otsu, 0,255, ThresholdTypes.Otsu|ThresholdTypes.Binary);
            Cv2.ImShow("otsu", otsu);
        }
        //___________________________________________________________________________________________________________________
        public void threshold_Adaptive()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("original", image);

            OpenCvSharp.Mat threshold = new OpenCvSharp.Mat();
            OpenCvSharp.Mat grayscaled = new OpenCvSharp.Mat();

            Cv2.CvtColor(image, grayscaled, ColorConversionCodes.BGR2GRAY);
            Cv2.Threshold(grayscaled, threshold, 15, 255, ThresholdTypes.Binary);
            Cv2.ImShow("threshold", threshold);

            OpenCvSharp.Mat adaptive = new OpenCvSharp.Mat();
            Cv2.AdaptiveThreshold(grayscaled, adaptive, 255, AdaptiveThresholdTypes.GaussianC, ThresholdTypes.Binary, 55, 1.0);
            Cv2.ImShow("adaptive", adaptive);
        }
        //___________________________________________________________________________________________________________________
        public void threshold()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("original", image);

            OpenCvSharp.Mat threshold=new OpenCvSharp.Mat(new Size(image.Width,image.Height),MatType.CV_8UC3,new Scalar(0));
            Cv2.Threshold(image,threshold,50,200,ThresholdTypes.Binary);
            Cv2.ImShow("thresh", threshold);
        }
            //___________________________________________________________________________________________________________________
            public void BitwiseNot()
        {

            OpenCvSharp.Mat image1 = OpenCvSharp.Mat.Zeros(new Size(400, 200), OpenCvSharp.MatType.CV_8UC1);
            OpenCvSharp.Mat image2 = OpenCvSharp.Mat.Zeros(new Size(400, 200), OpenCvSharp.MatType.CV_8UC1);

            Cv2.Rectangle(image1, new Rect(new Point(0, 0), new Size(image1.Cols / 2, image1.Rows)), new Scalar(255, 255, 255), -1);
            Cv2.ImShow("imsge1", image1);

            //Cv2.Rectangle(image2, new Rect(new Point(150, 100), new Size(200, 50)), new Scalar(255, 255, 255), -1);
            //Cv2.ImShow("imsge2", image2);

            OpenCvSharp.Mat bNotOp = new OpenCvSharp.Mat();
            Cv2.BitwiseNot(image1,bNotOp);
            Cv2.ImShow("bNotOp", bNotOp);
        }
        //___________________________________________________________________________________________________________________
        public void BitwiseXor()
        {

            OpenCvSharp.Mat image1 = OpenCvSharp.Mat.Zeros(new Size(400, 200), OpenCvSharp.MatType.CV_8UC1);
            OpenCvSharp.Mat image2 = OpenCvSharp.Mat.Zeros(new Size(400, 200), OpenCvSharp.MatType.CV_8UC1);

            Cv2.Rectangle(image1, new Rect(new Point(0, 0), new Size(image1.Cols / 2, image1.Rows)), new Scalar(255, 255, 255), -1);
            Cv2.ImShow("imsge1", image1);

            Cv2.Rectangle(image2, new Rect(new Point(150, 100), new Size(200, 50)), new Scalar(255, 255, 255), -1);
            Cv2.ImShow("imsge2", image2);

            OpenCvSharp.Mat XorOp = new OpenCvSharp.Mat();
            Cv2.BitwiseXor(image1, image2, XorOp);
            Cv2.ImShow("XorOp", XorOp);
        }
        //__________________________________________________________________________________
        public void BitwiseOr()
        {

            OpenCvSharp.Mat image1 = OpenCvSharp.Mat.Zeros(new Size(400, 200), OpenCvSharp.MatType.CV_8UC1);
            OpenCvSharp.Mat image2 = OpenCvSharp.Mat.Zeros(new Size(400, 200), OpenCvSharp.MatType.CV_8UC1);

            Cv2.Rectangle(image1, new Rect(new Point(0, 0), new Size(image1.Cols / 2, image1.Rows)), new Scalar(255, 255, 255), -1);
            Cv2.ImShow("imsge1", image1);

            Cv2.Rectangle(image2, new Rect(new Point(150, 100), new Size(200, 50)), new Scalar(255, 255, 255), -1);
            Cv2.ImShow("imsge2", image2);

            OpenCvSharp.Mat OrOp = new OpenCvSharp.Mat();
            Cv2.BitwiseOr(image1, image2, OrOp);
            Cv2.ImShow("OrOp", OrOp);
        }
        //__________________________________________________________________________________
        public void BitwiseAnd()
        {

            OpenCvSharp.Mat image1 = OpenCvSharp.Mat.Zeros(new Size(400,200),OpenCvSharp.MatType.CV_8UC1);
            OpenCvSharp.Mat image2 = OpenCvSharp.Mat.Zeros(new Size(400, 200), OpenCvSharp.MatType.CV_8UC1);

            Cv2.Rectangle(image1, new Rect(new Point(0, 0), new Size(image1.Cols / 2, image1.Rows)), new Scalar(255, 255, 255), -1);
            Cv2.ImShow("imsge1", image1);

            Cv2.Rectangle(image2, new Rect(new Point(150, 100), new Size(200,50)), new Scalar(255, 255, 255), -1);
            Cv2.ImShow("imsge2", image2);

            OpenCvSharp.Mat andOp = new OpenCvSharp.Mat();
            Cv2.BitwiseAnd(image1, image2, andOp);
            Cv2.ImShow("andOp", andOp);
        }
        //__________________________________________________________________________________
        public void flip()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("original", image);

            OpenCvSharp.Mat dest1 = new OpenCvSharp.Mat();
            OpenCvSharp.Mat dest2 = new OpenCvSharp.Mat();
            OpenCvSharp.Mat dest3 = new OpenCvSharp.Mat();

            Cv2.Flip(image, dest1, FlipMode.X);
            Cv2.Flip(image, dest2, FlipMode.Y);
            Cv2.Flip(image, dest3, FlipMode.XY);
        
            Cv2.ImShow("dst1", dest1);
            Cv2.ImShow("dst2", dest2);
            Cv2.ImShow("dst3", dest3);
        }
        //__________________________________________________________________________________
        public void resize()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("original", image);

            OpenCvSharp.Mat dest = new OpenCvSharp.Mat();
            Cv2.Resize(image, dest, new Size(image.Width/2, image.Height/2));
            Cv2.ImShow("resized1", dest);

            OpenCvSharp.Mat dest1 = new OpenCvSharp.Mat();
            Cv2.Resize(image, dest1, new Size(0,0),0.5,0.5);
            Cv2.ImShow("resized2", dest1);
        }
        //__________________________________________________________________________________
        public void rotation()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);

            var center = new Point2f(image.Width / 2, image.Height / 2);
            double angle = 45.0;
            OpenCvSharp.Mat RM = Cv2.GetRotationMatrix2D(center, angle, 1.0);
            OpenCvSharp.Mat dest = new OpenCvSharp.Mat();

            Cv2.WarpAffine(image, dest, RM, new Size(image.Width, image.Height));
            Cv2.ImShow("rotation", dest);
        }
        //__________________________________________________________________________________
        public void translate()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat image = Cv2.ImRead(path, ImreadModes.Color);

            //Translation Matrix
            // [1,0,tx]
            // [0,1,ty]
            float[] data = {1, 0, 50, 0, 1, 50};
            OpenCvSharp.Mat M = new OpenCvSharp.Mat(2, 3, OpenCvSharp.MatType.CV_32FC1, data);
            OpenCvSharp.Mat dest = new OpenCvSharp.Mat();
            Cv2.WarpAffine(image, dest, M, new Size(image.Width + 60, image.Height + 60));
            Cv2.ImShow("shifted", dest);
        }
        //__________________________________________________________________________________
        public void draw_line_circle_rect()
        {
            OpenCvSharp.Mat canvas = new OpenCvSharp.Mat(500, 500, MatType.CV_8UC3, new Scalar(255, 255, 255));
            Cv2.ImShow("canvas", canvas);
            var red = new Scalar(0, 0, 255);
            var blue = new Scalar(255, 0, 0);
            var green = new Scalar(0, 255, 0);
            var white = new Scalar(255, 255, 255);
            Cv2.Line(canvas, new Point(20, 20), new Point(200, 200), red, 5);
            //Cv2.Circle(canvas, new Point(60, 60),30, red, 3);
            //Cv2.Rectangle(canvas, new Rect(new Point(10, 10), new Size(50, 50)), white, 2);
        }
        //__________________________________________________________________________________
        public void channel_replace_by_indexer()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat color_Image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("Original", color_Image);

            int numRows = color_Image.Rows;
            int numCols = color_Image.Cols;
            OpenCvSharp.Mat cImage = color_Image.Clone();

            MatOfByte3 mat3 = new MatOfByte3(cImage);
            var indexer = mat3.GetIndexer();

            for (int y = 100; y < numRows-100; y++)
            {
                for (int x = 100; x < numCols-100; x++)
                {
                    Vec3b pixel = indexer[y, x];

                    byte blue = pixel.Item0;
                    byte red = pixel.Item2;
                    byte green = pixel.Item1;

                    byte temp = blue;
                    pixel.Item0 = red;
                    pixel.Item2 = temp;

                    indexer[y, x]=pixel;
                }
            }

            Cv2.ImShow("Swapped", cImage);

        }
        //__________________________________________________________________________________
        public void channel_replace()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat color_Image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("Original", color_Image);

            int numRows = color_Image.Rows;
            int numCols = color_Image.Cols;

            OpenCvSharp.Mat cImage = color_Image.Clone();

            for(int y=0;y<numRows;y++)
            {
                for(int x=0;x<numCols;x++)
                {
                    Vec3b pixel =cImage.Get<Vec3b>(y,x);

                    byte blue = pixel.Item0;
                    byte red = pixel.Item2;
                    byte green = pixel.Item1;

                    byte temp = blue;
                    pixel.Item0 = red;
                    pixel.Item2 = temp;

                    cImage.Set<Vec3b>(y, x, pixel);
                }
            }
             
            Cv2.ImShow("Swapped",cImage);

        }
        //__________________________________________________________________________________
        public void roi()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat color_Image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("Original", color_Image);

            OpenCvSharp.Mat roi_Image = new OpenCvSharp.Mat(color_Image, new Rect(50, 50, 250, 250));
            Cv2.ImShow("roi Image", roi_Image);

        }
        //__________________________________________________________________________________
        public void filter()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat color_Image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("Original", color_Image);

            OpenCvSharp.Mat[] channels;
            Cv2.Split(color_Image, out channels);

            Cv2.ImShow("Blue",channels[0]);
            Cv2.ImShow("Green", channels[1]);
            Cv2.ImShow("Red", channels[2]);
        }
        //__________________________________________________________________________________
        public void copy_clone()
        {
            string path = "D:\\lena.png";
            OpenCvSharp.Mat color_Image = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("Original", color_Image);

            OpenCvSharp.Mat cloned_Image = color_Image.Clone();
            Cv2.ImShow("Cloned", cloned_Image);

            OpenCvSharp.Mat another_cloned_Image = new OpenCvSharp.Mat();
            color_Image.CopyTo(another_cloned_Image);
            Cv2.ImShow("Another Cloned", another_cloned_Image);
        }
        //__________________________________________________________________________________
        public void create_object()
        {
            OpenCvSharp.Mat mat = new OpenCvSharp.Mat(30, 40, OpenCvSharp.MatType.CV_8UC3, new Scalar(0, 0, 255));
            OpenCvSharp.Mat mat1 = new OpenCvSharp.Mat(40, 30, OpenCvSharp.MatType.CV_8UC3, new Scalar(0, 255, 0));
            Cv2.ImShow("m", mat);
            Cv2.ImShow("m1", mat1);
        }
        //__________________________________________________________________________________
        public void display_gray_Image()
        {
            OpenCvSharp.Mat image = Cv2.ImRead("D:\\lena.png", ImreadModes.Grayscale);
            Cv2.ImShow("test_img", image);
            Cv2.ImWrite("D:\\Savedlena_gray.png", image);
        }
        //__________________________________________________________________________________
        public void display_colour_Image()
        {
          OpenCvSharp.Mat image = Cv2.ImRead("D:\\lena.png", ImreadModes.Color);
          Cv2.ImShow("test_img", image);
          Cv2.ImWrite("D:\\Savedlena.png", image);
        }
        //__________________________________________________________________________________
        









    }// class
}// namepsace
