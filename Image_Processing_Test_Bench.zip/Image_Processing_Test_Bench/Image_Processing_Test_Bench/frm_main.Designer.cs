﻿
namespace Test_Bench_For_Image_Process
{
    partial class frm_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_still_image_path = new System.Windows.Forms.TextBox();
            this.btn_browse_still_Image = new System.Windows.Forms.Button();
            this.rbtn_video_Image = new System.Windows.Forms.RadioButton();
            this.rbtn_still_Image = new System.Windows.Forms.RadioButton();
            this.cbo_video_channel_selection = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pb_still_original = new System.Windows.Forms.PictureBox();
            this.pb_still_edit = new System.Windows.Forms.PictureBox();
            this.btn_save_settings = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txt_zoom_val = new System.Windows.Forms.TextBox();
            this.hs_Zoom = new System.Windows.Forms.HScrollBar();
            this.btn_save_still_edited = new System.Windows.Forms.Button();
            this.btn_save_still_original = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pb_zoom = new System.Windows.Forms.PictureBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btn_dilate = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_erode = new System.Windows.Forms.Button();
            this.txt_erode_iteration = new System.Windows.Forms.TextBox();
            this.txt_erode_size = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btn_Canny_L2 = new System.Windows.Forms.Button();
            this.btn_Canny_Edge_L1 = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.btn_Sobel_XY64 = new System.Windows.Forms.Button();
            this.btn_sobel_XY = new System.Windows.Forms.Button();
            this.btn_sobel_Y = new System.Windows.Forms.Button();
            this.btn_sobel_X = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.btn_OTSU = new System.Windows.Forms.Button();
            this.btn_Adaptive_threshold = new System.Windows.Forms.Button();
            this.btn_binary_threshold = new System.Windows.Forms.Button();
            this.btn_motion_camera_next = new System.Windows.Forms.Button();
            this.btn_motion_camera_previous = new System.Windows.Forms.Button();
            this.txt_msg = new System.Windows.Forms.TextBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.rbtn_flip_XY = new System.Windows.Forms.RadioButton();
            this.rbtn_flip_Y = new System.Windows.Forms.RadioButton();
            this.rbtn_flip_X = new System.Windows.Forms.RadioButton();
            this.btn_flip_still_Image = new System.Windows.Forms.Button();
            this.btn_undo = new System.Windows.Forms.Button();
            this.btn_redo = new System.Windows.Forms.Button();
            this.btn_still_gray = new System.Windows.Forms.Button();
            this.btn_still_img_copy = new System.Windows.Forms.Button();
            this.timer_camera_read = new System.Windows.Forms.Timer(this.components);
            this.timer_program_runner = new System.Windows.Forms.Timer(this.components);
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.btn_find = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_contour_threshold = new System.Windows.Forms.TextBox();
            this.txt_contour_thickness = new System.Windows.Forms.TextBox();
            this.btn_contour_draw = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.chk_enable_auto_trigger = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_auto_trigger_step = new System.Windows.Forms.TextBox();
            this.txt_auto_trigger_running_val = new System.Windows.Forms.TextBox();
            this.txt_auto_trigger_max_val = new System.Windows.Forms.TextBox();
            this.txt_auto_trigger_interval = new System.Windows.Forms.TextBox();
            this.txt_auto_trigger_min_val = new System.Windows.Forms.TextBox();
            this.btn_auto_trigger_start = new System.Windows.Forms.Button();
            this.btn_auto_trigger_stop = new System.Windows.Forms.Button();
            this.timer_auto_trigger = new System.Windows.Forms.Timer(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_camera_reload = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_still_original)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_still_edit)).BeginInit();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_zoom)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox1.Controls.Add(this.btn_camera_reload);
            this.groupBox1.Controls.Add(this.btn_motion_camera_next);
            this.groupBox1.Controls.Add(this.btn_motion_camera_previous);
            this.groupBox1.Controls.Add(this.txt_still_image_path);
            this.groupBox1.Controls.Add(this.btn_browse_still_Image);
            this.groupBox1.Controls.Add(this.rbtn_video_Image);
            this.groupBox1.Controls.Add(this.rbtn_still_Image);
            this.groupBox1.Controls.Add(this.cbo_video_channel_selection);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(9, 605);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(419, 98);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Image Source";
            // 
            // txt_still_image_path
            // 
            this.txt_still_image_path.BackColor = System.Drawing.Color.Teal;
            this.txt_still_image_path.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_still_image_path.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_still_image_path.ForeColor = System.Drawing.Color.White;
            this.txt_still_image_path.Location = new System.Drawing.Point(81, 46);
            this.txt_still_image_path.Margin = new System.Windows.Forms.Padding(2);
            this.txt_still_image_path.Name = "txt_still_image_path";
            this.txt_still_image_path.Size = new System.Drawing.Size(232, 15);
            this.txt_still_image_path.TabIndex = 3;
            // 
            // btn_browse_still_Image
            // 
            this.btn_browse_still_Image.BackColor = System.Drawing.Color.Teal;
            this.btn_browse_still_Image.FlatAppearance.BorderSize = 0;
            this.btn_browse_still_Image.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_browse_still_Image.ForeColor = System.Drawing.Color.White;
            this.btn_browse_still_Image.Location = new System.Drawing.Point(81, 15);
            this.btn_browse_still_Image.Margin = new System.Windows.Forms.Padding(2);
            this.btn_browse_still_Image.Name = "btn_browse_still_Image";
            this.btn_browse_still_Image.Size = new System.Drawing.Size(232, 25);
            this.btn_browse_still_Image.TabIndex = 2;
            this.btn_browse_still_Image.Text = "Browse";
            this.btn_browse_still_Image.UseVisualStyleBackColor = false;
            this.btn_browse_still_Image.Click += new System.EventHandler(this.btn_browse_still_Image_Click);
            // 
            // rbtn_video_Image
            // 
            this.rbtn_video_Image.AutoSize = true;
            this.rbtn_video_Image.Location = new System.Drawing.Point(2, 70);
            this.rbtn_video_Image.Margin = new System.Windows.Forms.Padding(2);
            this.rbtn_video_Image.Name = "rbtn_video_Image";
            this.rbtn_video_Image.Size = new System.Drawing.Size(52, 17);
            this.rbtn_video_Image.TabIndex = 0;
            this.rbtn_video_Image.TabStop = true;
            this.rbtn_video_Image.Text = "Video";
            this.rbtn_video_Image.UseVisualStyleBackColor = true;
            this.rbtn_video_Image.CheckedChanged += new System.EventHandler(this.rbtn_video_Image_CheckedChanged);
            // 
            // rbtn_still_Image
            // 
            this.rbtn_still_Image.AutoSize = true;
            this.rbtn_still_Image.Location = new System.Drawing.Point(4, 44);
            this.rbtn_still_Image.Margin = new System.Windows.Forms.Padding(2);
            this.rbtn_still_Image.Name = "rbtn_still_Image";
            this.rbtn_still_Image.Size = new System.Drawing.Size(73, 17);
            this.rbtn_still_Image.TabIndex = 0;
            this.rbtn_still_Image.TabStop = true;
            this.rbtn_still_Image.Text = "Still Image";
            this.rbtn_still_Image.UseVisualStyleBackColor = true;
            this.rbtn_still_Image.CheckedChanged += new System.EventHandler(this.rbtn_still_Image_CheckedChanged);
            // 
            // cbo_video_channel_selection
            // 
            this.cbo_video_channel_selection.BackColor = System.Drawing.Color.Teal;
            this.cbo_video_channel_selection.ForeColor = System.Drawing.Color.White;
            this.cbo_video_channel_selection.FormattingEnabled = true;
            this.cbo_video_channel_selection.Location = new System.Drawing.Point(58, 68);
            this.cbo_video_channel_selection.Margin = new System.Windows.Forms.Padding(2);
            this.cbo_video_channel_selection.Name = "cbo_video_channel_selection";
            this.cbo_video_channel_selection.Size = new System.Drawing.Size(176, 21);
            this.cbo_video_channel_selection.TabIndex = 0;
            this.cbo_video_channel_selection.SelectedIndexChanged += new System.EventHandler(this.cbo_video_channel_selection_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cooper Black", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label2.Location = new System.Drawing.Point(752, 3);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(360, 27);
            this.label2.TabIndex = 2;
            this.label2.Text = "Image Processing Test Bench";
            // 
            // pb_still_original
            // 
            this.pb_still_original.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_still_original.Location = new System.Drawing.Point(4, 35);
            this.pb_still_original.Margin = new System.Windows.Forms.Padding(2);
            this.pb_still_original.Name = "pb_still_original";
            this.pb_still_original.Size = new System.Drawing.Size(595, 518);
            this.pb_still_original.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_still_original.TabIndex = 0;
            this.pb_still_original.TabStop = false;
            // 
            // pb_still_edit
            // 
            this.pb_still_edit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_still_edit.Location = new System.Drawing.Point(604, 35);
            this.pb_still_edit.Margin = new System.Windows.Forms.Padding(2);
            this.pb_still_edit.Name = "pb_still_edit";
            this.pb_still_edit.Size = new System.Drawing.Size(614, 518);
            this.pb_still_edit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_still_edit.TabIndex = 0;
            this.pb_still_edit.TabStop = false;
            this.pb_still_edit.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pb_still_edit_MouseMove);
            // 
            // btn_save_settings
            // 
            this.btn_save_settings.BackColor = System.Drawing.Color.Teal;
            this.btn_save_settings.FlatAppearance.BorderSize = 0;
            this.btn_save_settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save_settings.ForeColor = System.Drawing.Color.White;
            this.btn_save_settings.Location = new System.Drawing.Point(1713, 608);
            this.btn_save_settings.Name = "btn_save_settings";
            this.btn_save_settings.Size = new System.Drawing.Size(78, 119);
            this.btn_save_settings.TabIndex = 7;
            this.btn_save_settings.Text = "Save Settings";
            this.btn_save_settings.UseVisualStyleBackColor = false;
            this.btn_save_settings.Click += new System.EventHandler(this.btn_save_settings_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txt_zoom_val);
            this.groupBox7.Controls.Add(this.hs_Zoom);
            this.groupBox7.Controls.Add(this.btn_save_still_edited);
            this.groupBox7.Controls.Add(this.btn_save_still_original);
            this.groupBox7.Controls.Add(this.label3);
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.label1);
            this.groupBox7.Controls.Add(this.pb_zoom);
            this.groupBox7.Controls.Add(this.pb_still_edit);
            this.groupBox7.Controls.Add(this.pb_still_original);
            this.groupBox7.ForeColor = System.Drawing.Color.White;
            this.groupBox7.Location = new System.Drawing.Point(9, 33);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1782, 567);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Still Image";
            // 
            // txt_zoom_val
            // 
            this.txt_zoom_val.Location = new System.Drawing.Point(1704, 10);
            this.txt_zoom_val.Name = "txt_zoom_val";
            this.txt_zoom_val.Size = new System.Drawing.Size(52, 20);
            this.txt_zoom_val.TabIndex = 19;
            // 
            // hs_Zoom
            // 
            this.hs_Zoom.Location = new System.Drawing.Point(1410, 11);
            this.hs_Zoom.Minimum = 1;
            this.hs_Zoom.Name = "hs_Zoom";
            this.hs_Zoom.Size = new System.Drawing.Size(287, 20);
            this.hs_Zoom.TabIndex = 18;
            this.hs_Zoom.Value = 1;
            this.hs_Zoom.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hs_Zoom_Scroll);
            // 
            // btn_save_still_edited
            // 
            this.btn_save_still_edited.BackColor = System.Drawing.Color.Teal;
            this.btn_save_still_edited.FlatAppearance.BorderSize = 0;
            this.btn_save_still_edited.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save_still_edited.Location = new System.Drawing.Point(1142, 9);
            this.btn_save_still_edited.Name = "btn_save_still_edited";
            this.btn_save_still_edited.Size = new System.Drawing.Size(75, 24);
            this.btn_save_still_edited.TabIndex = 3;
            this.btn_save_still_edited.Text = "Save";
            this.btn_save_still_edited.UseVisualStyleBackColor = false;
            this.btn_save_still_edited.Click += new System.EventHandler(this.btn_save_still_edited_Click);
            // 
            // btn_save_still_original
            // 
            this.btn_save_still_original.BackColor = System.Drawing.Color.Teal;
            this.btn_save_still_original.FlatAppearance.BorderSize = 0;
            this.btn_save_still_original.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save_still_original.ForeColor = System.Drawing.Color.White;
            this.btn_save_still_original.Location = new System.Drawing.Point(525, 10);
            this.btn_save_still_original.Name = "btn_save_still_original";
            this.btn_save_still_original.Size = new System.Drawing.Size(75, 24);
            this.btn_save_still_original.TabIndex = 3;
            this.btn_save_still_original.Text = "Save";
            this.btn_save_still_original.UseVisualStyleBackColor = false;
            this.btn_save_still_original.Click += new System.EventHandler(this.btn_save_still_original_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1278, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Zoom Window";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(866, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Edited";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(276, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Original";
            // 
            // pb_zoom
            // 
            this.pb_zoom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb_zoom.Location = new System.Drawing.Point(1222, 35);
            this.pb_zoom.Margin = new System.Windows.Forms.Padding(2);
            this.pb_zoom.Name = "pb_zoom";
            this.pb_zoom.Size = new System.Drawing.Size(554, 518);
            this.pb_zoom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_zoom.TabIndex = 0;
            this.pb_zoom.TabStop = false;
            this.pb_zoom.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pb_zoom_MouseMove);
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox8.Controls.Add(this.btn_dilate);
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Controls.Add(this.label7);
            this.groupBox8.Controls.Add(this.btn_erode);
            this.groupBox8.Controls.Add(this.txt_erode_iteration);
            this.groupBox8.Controls.Add(this.txt_erode_size);
            this.groupBox8.ForeColor = System.Drawing.Color.White;
            this.groupBox8.Location = new System.Drawing.Point(1046, 606);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(338, 48);
            this.groupBox8.TabIndex = 11;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Morphology";
            // 
            // btn_dilate
            // 
            this.btn_dilate.BackColor = System.Drawing.Color.Teal;
            this.btn_dilate.FlatAppearance.BorderSize = 0;
            this.btn_dilate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_dilate.ForeColor = System.Drawing.Color.White;
            this.btn_dilate.Location = new System.Drawing.Point(244, 14);
            this.btn_dilate.Name = "btn_dilate";
            this.btn_dilate.Size = new System.Drawing.Size(86, 23);
            this.btn_dilate.TabIndex = 4;
            this.btn_dilate.Text = "DILATE";
            this.btn_dilate.UseVisualStyleBackColor = false;
            this.btn_dilate.Click += new System.EventHandler(this.btn_dilate_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(75, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Iteration";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Size";
            // 
            // btn_erode
            // 
            this.btn_erode.BackColor = System.Drawing.Color.Teal;
            this.btn_erode.FlatAppearance.BorderSize = 0;
            this.btn_erode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_erode.ForeColor = System.Drawing.Color.White;
            this.btn_erode.Location = new System.Drawing.Point(154, 15);
            this.btn_erode.Name = "btn_erode";
            this.btn_erode.Size = new System.Drawing.Size(86, 23);
            this.btn_erode.TabIndex = 2;
            this.btn_erode.Text = "ERODE";
            this.btn_erode.UseVisualStyleBackColor = false;
            this.btn_erode.Click += new System.EventHandler(this.btn_erode_Click);
            // 
            // txt_erode_iteration
            // 
            this.txt_erode_iteration.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_erode_iteration.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_erode_iteration.Location = new System.Drawing.Point(120, 18);
            this.txt_erode_iteration.Name = "txt_erode_iteration";
            this.txt_erode_iteration.Size = new System.Drawing.Size(28, 15);
            this.txt_erode_iteration.TabIndex = 1;
            this.txt_erode_iteration.Text = "1";
            // 
            // txt_erode_size
            // 
            this.txt_erode_size.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_erode_size.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_erode_size.Location = new System.Drawing.Point(32, 17);
            this.txt_erode_size.Name = "txt_erode_size";
            this.txt_erode_size.Size = new System.Drawing.Size(39, 15);
            this.txt_erode_size.TabIndex = 1;
            this.txt_erode_size.Text = "3";
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox9.Controls.Add(this.btn_Canny_L2);
            this.groupBox9.Controls.Add(this.btn_Canny_Edge_L1);
            this.groupBox9.ForeColor = System.Drawing.Color.White;
            this.groupBox9.Location = new System.Drawing.Point(1488, 605);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(100, 123);
            this.groupBox9.TabIndex = 11;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Edge Detection";
            // 
            // btn_Canny_L2
            // 
            this.btn_Canny_L2.BackColor = System.Drawing.Color.Teal;
            this.btn_Canny_L2.FlatAppearance.BorderSize = 0;
            this.btn_Canny_L2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Canny_L2.ForeColor = System.Drawing.Color.White;
            this.btn_Canny_L2.Location = new System.Drawing.Point(6, 67);
            this.btn_Canny_L2.Name = "btn_Canny_L2";
            this.btn_Canny_L2.Size = new System.Drawing.Size(88, 47);
            this.btn_Canny_L2.TabIndex = 1;
            this.btn_Canny_L2.Text = "CANNY L2";
            this.btn_Canny_L2.UseVisualStyleBackColor = false;
            this.btn_Canny_L2.Click += new System.EventHandler(this.btn_Canny_L2_Click);
            // 
            // btn_Canny_Edge_L1
            // 
            this.btn_Canny_Edge_L1.BackColor = System.Drawing.Color.Teal;
            this.btn_Canny_Edge_L1.FlatAppearance.BorderSize = 0;
            this.btn_Canny_Edge_L1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Canny_Edge_L1.ForeColor = System.Drawing.Color.White;
            this.btn_Canny_Edge_L1.Location = new System.Drawing.Point(6, 19);
            this.btn_Canny_Edge_L1.Name = "btn_Canny_Edge_L1";
            this.btn_Canny_Edge_L1.Size = new System.Drawing.Size(88, 39);
            this.btn_Canny_Edge_L1.TabIndex = 0;
            this.btn_Canny_Edge_L1.Text = "CNAAY L1";
            this.btn_Canny_Edge_L1.UseVisualStyleBackColor = false;
            this.btn_Canny_Edge_L1.Click += new System.EventHandler(this.btn_Canny_Edge_L1_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.btn_Sobel_XY64);
            this.groupBox10.Controls.Add(this.btn_sobel_XY);
            this.groupBox10.Controls.Add(this.btn_sobel_Y);
            this.groupBox10.Controls.Add(this.btn_sobel_X);
            this.groupBox10.ForeColor = System.Drawing.Color.White;
            this.groupBox10.Location = new System.Drawing.Point(1594, 605);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(112, 123);
            this.groupBox10.TabIndex = 11;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "SOBEL Filter";
            // 
            // btn_Sobel_XY64
            // 
            this.btn_Sobel_XY64.BackColor = System.Drawing.Color.Teal;
            this.btn_Sobel_XY64.FlatAppearance.BorderSize = 0;
            this.btn_Sobel_XY64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Sobel_XY64.ForeColor = System.Drawing.Color.White;
            this.btn_Sobel_XY64.Location = new System.Drawing.Point(56, 63);
            this.btn_Sobel_XY64.Name = "btn_Sobel_XY64";
            this.btn_Sobel_XY64.Size = new System.Drawing.Size(46, 43);
            this.btn_Sobel_XY64.TabIndex = 1;
            this.btn_Sobel_XY64.Text = "XY64";
            this.btn_Sobel_XY64.UseVisualStyleBackColor = false;
            this.btn_Sobel_XY64.Click += new System.EventHandler(this.btn_Sobel_XY64_Click);
            // 
            // btn_sobel_XY
            // 
            this.btn_sobel_XY.BackColor = System.Drawing.Color.Teal;
            this.btn_sobel_XY.FlatAppearance.BorderSize = 0;
            this.btn_sobel_XY.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sobel_XY.ForeColor = System.Drawing.Color.White;
            this.btn_sobel_XY.Location = new System.Drawing.Point(6, 63);
            this.btn_sobel_XY.Name = "btn_sobel_XY";
            this.btn_sobel_XY.Size = new System.Drawing.Size(44, 44);
            this.btn_sobel_XY.TabIndex = 0;
            this.btn_sobel_XY.Text = "XY";
            this.btn_sobel_XY.UseVisualStyleBackColor = false;
            this.btn_sobel_XY.Click += new System.EventHandler(this.btn_sobel_XY_Click);
            // 
            // btn_sobel_Y
            // 
            this.btn_sobel_Y.BackColor = System.Drawing.Color.Teal;
            this.btn_sobel_Y.FlatAppearance.BorderSize = 0;
            this.btn_sobel_Y.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sobel_Y.ForeColor = System.Drawing.Color.White;
            this.btn_sobel_Y.Location = new System.Drawing.Point(56, 24);
            this.btn_sobel_Y.Name = "btn_sobel_Y";
            this.btn_sobel_Y.Size = new System.Drawing.Size(46, 33);
            this.btn_sobel_Y.TabIndex = 0;
            this.btn_sobel_Y.Text = "Y";
            this.btn_sobel_Y.UseVisualStyleBackColor = false;
            this.btn_sobel_Y.Click += new System.EventHandler(this.btn_sobel_Y_Click);
            // 
            // btn_sobel_X
            // 
            this.btn_sobel_X.BackColor = System.Drawing.Color.Teal;
            this.btn_sobel_X.FlatAppearance.BorderSize = 0;
            this.btn_sobel_X.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sobel_X.ForeColor = System.Drawing.Color.White;
            this.btn_sobel_X.Location = new System.Drawing.Point(6, 25);
            this.btn_sobel_X.Name = "btn_sobel_X";
            this.btn_sobel_X.Size = new System.Drawing.Size(44, 32);
            this.btn_sobel_X.TabIndex = 0;
            this.btn_sobel_X.Text = "X";
            this.btn_sobel_X.UseVisualStyleBackColor = false;
            this.btn_sobel_X.Click += new System.EventHandler(this.btn_sobel_X_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox11.Controls.Add(this.btn_OTSU);
            this.groupBox11.Controls.Add(this.btn_Adaptive_threshold);
            this.groupBox11.Controls.Add(this.btn_binary_threshold);
            this.groupBox11.ForeColor = System.Drawing.Color.White;
            this.groupBox11.Location = new System.Drawing.Point(1389, 605);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(93, 124);
            this.groupBox11.TabIndex = 11;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Thresolding";
            // 
            // btn_OTSU
            // 
            this.btn_OTSU.BackColor = System.Drawing.Color.Teal;
            this.btn_OTSU.FlatAppearance.BorderSize = 0;
            this.btn_OTSU.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_OTSU.Location = new System.Drawing.Point(6, 84);
            this.btn_OTSU.Name = "btn_OTSU";
            this.btn_OTSU.Size = new System.Drawing.Size(75, 23);
            this.btn_OTSU.TabIndex = 1;
            this.btn_OTSU.Text = "OTSU";
            this.btn_OTSU.UseVisualStyleBackColor = false;
            this.btn_OTSU.Click += new System.EventHandler(this.btn_OTSU_Click);
            // 
            // btn_Adaptive_threshold
            // 
            this.btn_Adaptive_threshold.BackColor = System.Drawing.Color.Teal;
            this.btn_Adaptive_threshold.FlatAppearance.BorderSize = 0;
            this.btn_Adaptive_threshold.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Adaptive_threshold.Location = new System.Drawing.Point(6, 54);
            this.btn_Adaptive_threshold.Name = "btn_Adaptive_threshold";
            this.btn_Adaptive_threshold.Size = new System.Drawing.Size(75, 23);
            this.btn_Adaptive_threshold.TabIndex = 1;
            this.btn_Adaptive_threshold.Text = "Adaptive";
            this.btn_Adaptive_threshold.UseVisualStyleBackColor = false;
            this.btn_Adaptive_threshold.Click += new System.EventHandler(this.btn_Adaptive_threshold_Click);
            // 
            // btn_binary_threshold
            // 
            this.btn_binary_threshold.BackColor = System.Drawing.Color.Teal;
            this.btn_binary_threshold.FlatAppearance.BorderSize = 0;
            this.btn_binary_threshold.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_binary_threshold.Location = new System.Drawing.Point(6, 25);
            this.btn_binary_threshold.Name = "btn_binary_threshold";
            this.btn_binary_threshold.Size = new System.Drawing.Size(75, 23);
            this.btn_binary_threshold.TabIndex = 0;
            this.btn_binary_threshold.Text = "BINARY";
            this.btn_binary_threshold.UseVisualStyleBackColor = false;
            this.btn_binary_threshold.Click += new System.EventHandler(this.btn_binary_threshold_Click);
            // 
            // btn_motion_camera_next
            // 
            this.btn_motion_camera_next.BackColor = System.Drawing.Color.Teal;
            this.btn_motion_camera_next.FlatAppearance.BorderSize = 0;
            this.btn_motion_camera_next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_motion_camera_next.ForeColor = System.Drawing.Color.White;
            this.btn_motion_camera_next.Location = new System.Drawing.Point(273, 66);
            this.btn_motion_camera_next.Name = "btn_motion_camera_next";
            this.btn_motion_camera_next.Size = new System.Drawing.Size(40, 23);
            this.btn_motion_camera_next.TabIndex = 12;
            this.btn_motion_camera_next.Text = ">>";
            this.btn_motion_camera_next.UseVisualStyleBackColor = false;
            this.btn_motion_camera_next.Click += new System.EventHandler(this.btn_motion_camera_next_Click);
            // 
            // btn_motion_camera_previous
            // 
            this.btn_motion_camera_previous.BackColor = System.Drawing.Color.Teal;
            this.btn_motion_camera_previous.FlatAppearance.BorderSize = 0;
            this.btn_motion_camera_previous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_motion_camera_previous.ForeColor = System.Drawing.Color.White;
            this.btn_motion_camera_previous.Location = new System.Drawing.Point(239, 66);
            this.btn_motion_camera_previous.Name = "btn_motion_camera_previous";
            this.btn_motion_camera_previous.Size = new System.Drawing.Size(28, 24);
            this.btn_motion_camera_previous.TabIndex = 12;
            this.btn_motion_camera_previous.Text = "<<";
            this.btn_motion_camera_previous.UseVisualStyleBackColor = false;
            this.btn_motion_camera_previous.Click += new System.EventHandler(this.btn_motion_camera_previous_Click);
            // 
            // txt_msg
            // 
            this.txt_msg.BackColor = System.Drawing.Color.Teal;
            this.txt_msg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_msg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_msg.ForeColor = System.Drawing.Color.White;
            this.txt_msg.Location = new System.Drawing.Point(9, 708);
            this.txt_msg.Name = "txt_msg";
            this.txt_msg.Size = new System.Drawing.Size(418, 19);
            this.txt_msg.TabIndex = 14;
            this.txt_msg.Text = "Message";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.btn_undo);
            this.groupBox15.Controls.Add(this.btn_redo);
            this.groupBox15.Controls.Add(this.btn_still_gray);
            this.groupBox15.Controls.Add(this.btn_still_img_copy);
            this.groupBox15.ForeColor = System.Drawing.Color.White;
            this.groupBox15.Location = new System.Drawing.Point(433, 605);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(152, 124);
            this.groupBox15.TabIndex = 15;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "IMAGE";
            // 
            // rbtn_flip_XY
            // 
            this.rbtn_flip_XY.AutoSize = true;
            this.rbtn_flip_XY.Location = new System.Drawing.Point(85, 27);
            this.rbtn_flip_XY.Name = "rbtn_flip_XY";
            this.rbtn_flip_XY.Size = new System.Drawing.Size(39, 17);
            this.rbtn_flip_XY.TabIndex = 2;
            this.rbtn_flip_XY.TabStop = true;
            this.rbtn_flip_XY.Text = "XY";
            this.rbtn_flip_XY.UseVisualStyleBackColor = true;
            this.rbtn_flip_XY.CheckedChanged += new System.EventHandler(this.rbtn_flip_XY_CheckedChanged);
            // 
            // rbtn_flip_Y
            // 
            this.rbtn_flip_Y.AutoSize = true;
            this.rbtn_flip_Y.Location = new System.Drawing.Point(47, 27);
            this.rbtn_flip_Y.Name = "rbtn_flip_Y";
            this.rbtn_flip_Y.Size = new System.Drawing.Size(32, 17);
            this.rbtn_flip_Y.TabIndex = 2;
            this.rbtn_flip_Y.TabStop = true;
            this.rbtn_flip_Y.Text = "Y";
            this.rbtn_flip_Y.UseVisualStyleBackColor = true;
            this.rbtn_flip_Y.CheckedChanged += new System.EventHandler(this.rbtn_flip_Y_CheckedChanged);
            // 
            // rbtn_flip_X
            // 
            this.rbtn_flip_X.AutoSize = true;
            this.rbtn_flip_X.Location = new System.Drawing.Point(9, 28);
            this.rbtn_flip_X.Name = "rbtn_flip_X";
            this.rbtn_flip_X.Size = new System.Drawing.Size(32, 17);
            this.rbtn_flip_X.TabIndex = 2;
            this.rbtn_flip_X.TabStop = true;
            this.rbtn_flip_X.Text = "X";
            this.rbtn_flip_X.UseVisualStyleBackColor = true;
            this.rbtn_flip_X.CheckedChanged += new System.EventHandler(this.rbtn_flip_X_CheckedChanged);
            // 
            // btn_flip_still_Image
            // 
            this.btn_flip_still_Image.BackColor = System.Drawing.Color.Teal;
            this.btn_flip_still_Image.FlatAppearance.BorderSize = 0;
            this.btn_flip_still_Image.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_flip_still_Image.ForeColor = System.Drawing.Color.White;
            this.btn_flip_still_Image.Location = new System.Drawing.Point(6, 58);
            this.btn_flip_still_Image.Name = "btn_flip_still_Image";
            this.btn_flip_still_Image.Size = new System.Drawing.Size(118, 45);
            this.btn_flip_still_Image.TabIndex = 1;
            this.btn_flip_still_Image.Text = "FLIP";
            this.btn_flip_still_Image.UseVisualStyleBackColor = false;
            this.btn_flip_still_Image.Click += new System.EventHandler(this.btn_flip_still_Image_Click);
            // 
            // btn_undo
            // 
            this.btn_undo.BackColor = System.Drawing.Color.Teal;
            this.btn_undo.FlatAppearance.BorderSize = 0;
            this.btn_undo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_undo.ForeColor = System.Drawing.Color.White;
            this.btn_undo.Location = new System.Drawing.Point(10, 84);
            this.btn_undo.Name = "btn_undo";
            this.btn_undo.Size = new System.Drawing.Size(65, 23);
            this.btn_undo.TabIndex = 1;
            this.btn_undo.Text = "UNDO";
            this.btn_undo.UseVisualStyleBackColor = false;
            // 
            // btn_redo
            // 
            this.btn_redo.BackColor = System.Drawing.Color.Teal;
            this.btn_redo.FlatAppearance.BorderSize = 0;
            this.btn_redo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_redo.ForeColor = System.Drawing.Color.White;
            this.btn_redo.Location = new System.Drawing.Point(80, 84);
            this.btn_redo.Name = "btn_redo";
            this.btn_redo.Size = new System.Drawing.Size(64, 23);
            this.btn_redo.TabIndex = 1;
            this.btn_redo.Text = "REDO";
            this.btn_redo.UseVisualStyleBackColor = false;
            // 
            // btn_still_gray
            // 
            this.btn_still_gray.BackColor = System.Drawing.Color.Teal;
            this.btn_still_gray.FlatAppearance.BorderSize = 0;
            this.btn_still_gray.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_still_gray.ForeColor = System.Drawing.Color.White;
            this.btn_still_gray.Location = new System.Drawing.Point(10, 49);
            this.btn_still_gray.Name = "btn_still_gray";
            this.btn_still_gray.Size = new System.Drawing.Size(134, 32);
            this.btn_still_gray.TabIndex = 1;
            this.btn_still_gray.Text = "CONVERT TO GRAY";
            this.btn_still_gray.UseVisualStyleBackColor = false;
            this.btn_still_gray.Click += new System.EventHandler(this.btn_still_gray_Click);
            // 
            // btn_still_img_copy
            // 
            this.btn_still_img_copy.BackColor = System.Drawing.Color.Teal;
            this.btn_still_img_copy.FlatAppearance.BorderSize = 0;
            this.btn_still_img_copy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_still_img_copy.ForeColor = System.Drawing.Color.White;
            this.btn_still_img_copy.Location = new System.Drawing.Point(10, 20);
            this.btn_still_img_copy.Name = "btn_still_img_copy";
            this.btn_still_img_copy.Size = new System.Drawing.Size(134, 26);
            this.btn_still_img_copy.TabIndex = 0;
            this.btn_still_img_copy.Text = "COPY TO EDIT BOX";
            this.btn_still_img_copy.UseVisualStyleBackColor = false;
            this.btn_still_img_copy.Click += new System.EventHandler(this.btn_still_img_copy_Click);
            // 
            // timer_camera_read
            // 
            this.timer_camera_read.Interval = 1000;
            this.timer_camera_read.Tick += new System.EventHandler(this.timer_camera_read_Tick);
            // 
            // groupBox16
            // 
            this.groupBox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox16.Controls.Add(this.btn_find);
            this.groupBox16.Controls.Add(this.label10);
            this.groupBox16.Controls.Add(this.label9);
            this.groupBox16.Controls.Add(this.txt_contour_threshold);
            this.groupBox16.Controls.Add(this.txt_contour_thickness);
            this.groupBox16.Controls.Add(this.btn_contour_draw);
            this.groupBox16.ForeColor = System.Drawing.Color.White;
            this.groupBox16.Location = new System.Drawing.Point(1046, 657);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(338, 72);
            this.groupBox16.TabIndex = 16;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Contour";
            // 
            // btn_find
            // 
            this.btn_find.BackColor = System.Drawing.Color.Teal;
            this.btn_find.FlatAppearance.BorderSize = 0;
            this.btn_find.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_find.ForeColor = System.Drawing.Color.White;
            this.btn_find.Location = new System.Drawing.Point(186, 16);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(146, 46);
            this.btn_find.TabIndex = 6;
            this.btn_find.Text = "FIND";
            this.btn_find.UseVisualStyleBackColor = false;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "Threshold";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Thickness";
            // 
            // txt_contour_threshold
            // 
            this.txt_contour_threshold.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_contour_threshold.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_contour_threshold.Location = new System.Drawing.Point(74, 43);
            this.txt_contour_threshold.Name = "txt_contour_threshold";
            this.txt_contour_threshold.Size = new System.Drawing.Size(39, 15);
            this.txt_contour_threshold.TabIndex = 4;
            this.txt_contour_threshold.Text = "100";
            // 
            // txt_contour_thickness
            // 
            this.txt_contour_thickness.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_contour_thickness.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_contour_thickness.Location = new System.Drawing.Point(74, 21);
            this.txt_contour_thickness.Name = "txt_contour_thickness";
            this.txt_contour_thickness.Size = new System.Drawing.Size(39, 15);
            this.txt_contour_thickness.TabIndex = 4;
            this.txt_contour_thickness.Text = "1";
            // 
            // btn_contour_draw
            // 
            this.btn_contour_draw.BackColor = System.Drawing.Color.Teal;
            this.btn_contour_draw.FlatAppearance.BorderSize = 0;
            this.btn_contour_draw.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_contour_draw.ForeColor = System.Drawing.Color.White;
            this.btn_contour_draw.Location = new System.Drawing.Point(118, 18);
            this.btn_contour_draw.Name = "btn_contour_draw";
            this.btn_contour_draw.Size = new System.Drawing.Size(62, 45);
            this.btn_contour_draw.TabIndex = 0;
            this.btn_contour_draw.Text = "DRAW";
            this.btn_contour_draw.UseVisualStyleBackColor = false;
            this.btn_contour_draw.Click += new System.EventHandler(this.btn_contour_draw_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox17.Controls.Add(this.chk_enable_auto_trigger);
            this.groupBox17.Controls.Add(this.label15);
            this.groupBox17.Controls.Add(this.label14);
            this.groupBox17.Controls.Add(this.label12);
            this.groupBox17.Controls.Add(this.label13);
            this.groupBox17.Controls.Add(this.label11);
            this.groupBox17.Controls.Add(this.txt_auto_trigger_step);
            this.groupBox17.Controls.Add(this.txt_auto_trigger_running_val);
            this.groupBox17.Controls.Add(this.txt_auto_trigger_max_val);
            this.groupBox17.Controls.Add(this.txt_auto_trigger_interval);
            this.groupBox17.Controls.Add(this.txt_auto_trigger_min_val);
            this.groupBox17.Controls.Add(this.btn_auto_trigger_start);
            this.groupBox17.Controls.Add(this.btn_auto_trigger_stop);
            this.groupBox17.ForeColor = System.Drawing.Color.White;
            this.groupBox17.Location = new System.Drawing.Point(730, 606);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(309, 123);
            this.groupBox17.TabIndex = 17;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "AUTO TRIGGER";
            // 
            // chk_enable_auto_trigger
            // 
            this.chk_enable_auto_trigger.AutoSize = true;
            this.chk_enable_auto_trigger.Checked = true;
            this.chk_enable_auto_trigger.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk_enable_auto_trigger.ForeColor = System.Drawing.Color.White;
            this.chk_enable_auto_trigger.Location = new System.Drawing.Point(6, 17);
            this.chk_enable_auto_trigger.Name = "chk_enable_auto_trigger";
            this.chk_enable_auto_trigger.Size = new System.Drawing.Size(59, 17);
            this.chk_enable_auto_trigger.TabIndex = 3;
            this.chk_enable_auto_trigger.Text = "Enable";
            this.chk_enable_auto_trigger.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(207, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 13);
            this.label15.TabIndex = 2;
            this.label15.Text = "Step";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(188, 42);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Running.";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(98, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 13);
            this.label12.TabIndex = 2;
            this.label12.Text = "Max.";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(80, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 13);
            this.label13.TabIndex = 2;
            this.label13.Text = "Interval";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(8, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "Min.";
            // 
            // txt_auto_trigger_step
            // 
            this.txt_auto_trigger_step.BackColor = System.Drawing.Color.White;
            this.txt_auto_trigger_step.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_auto_trigger_step.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_auto_trigger_step.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_auto_trigger_step.Location = new System.Drawing.Point(240, 19);
            this.txt_auto_trigger_step.Name = "txt_auto_trigger_step";
            this.txt_auto_trigger_step.Size = new System.Drawing.Size(56, 15);
            this.txt_auto_trigger_step.TabIndex = 1;
            this.txt_auto_trigger_step.Text = "1";
            // 
            // txt_auto_trigger_running_val
            // 
            this.txt_auto_trigger_running_val.BackColor = System.Drawing.Color.White;
            this.txt_auto_trigger_running_val.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_auto_trigger_running_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_auto_trigger_running_val.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_auto_trigger_running_val.Location = new System.Drawing.Point(240, 41);
            this.txt_auto_trigger_running_val.Name = "txt_auto_trigger_running_val";
            this.txt_auto_trigger_running_val.Size = new System.Drawing.Size(56, 15);
            this.txt_auto_trigger_running_val.TabIndex = 1;
            this.txt_auto_trigger_running_val.Text = "0";
            // 
            // txt_auto_trigger_max_val
            // 
            this.txt_auto_trigger_max_val.BackColor = System.Drawing.Color.White;
            this.txt_auto_trigger_max_val.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_auto_trigger_max_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_auto_trigger_max_val.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_auto_trigger_max_val.Location = new System.Drawing.Point(129, 42);
            this.txt_auto_trigger_max_val.Name = "txt_auto_trigger_max_val";
            this.txt_auto_trigger_max_val.Size = new System.Drawing.Size(56, 15);
            this.txt_auto_trigger_max_val.TabIndex = 1;
            this.txt_auto_trigger_max_val.Text = "255";
            // 
            // txt_auto_trigger_interval
            // 
            this.txt_auto_trigger_interval.BackColor = System.Drawing.Color.White;
            this.txt_auto_trigger_interval.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_auto_trigger_interval.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_auto_trigger_interval.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_auto_trigger_interval.Location = new System.Drawing.Point(130, 18);
            this.txt_auto_trigger_interval.Name = "txt_auto_trigger_interval";
            this.txt_auto_trigger_interval.Size = new System.Drawing.Size(56, 15);
            this.txt_auto_trigger_interval.TabIndex = 1;
            this.txt_auto_trigger_interval.Text = "100";
            // 
            // txt_auto_trigger_min_val
            // 
            this.txt_auto_trigger_min_val.BackColor = System.Drawing.Color.White;
            this.txt_auto_trigger_min_val.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_auto_trigger_min_val.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_auto_trigger_min_val.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txt_auto_trigger_min_val.Location = new System.Drawing.Point(38, 42);
            this.txt_auto_trigger_min_val.Name = "txt_auto_trigger_min_val";
            this.txt_auto_trigger_min_val.Size = new System.Drawing.Size(56, 15);
            this.txt_auto_trigger_min_val.TabIndex = 1;
            this.txt_auto_trigger_min_val.Text = "0";
            // 
            // btn_auto_trigger_start
            // 
            this.btn_auto_trigger_start.BackColor = System.Drawing.Color.Teal;
            this.btn_auto_trigger_start.FlatAppearance.BorderSize = 0;
            this.btn_auto_trigger_start.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_auto_trigger_start.ForeColor = System.Drawing.Color.White;
            this.btn_auto_trigger_start.Location = new System.Drawing.Point(12, 67);
            this.btn_auto_trigger_start.Name = "btn_auto_trigger_start";
            this.btn_auto_trigger_start.Size = new System.Drawing.Size(126, 40);
            this.btn_auto_trigger_start.TabIndex = 0;
            this.btn_auto_trigger_start.Text = "START";
            this.btn_auto_trigger_start.UseVisualStyleBackColor = false;
            this.btn_auto_trigger_start.Click += new System.EventHandler(this.btn_auto_trigger_start_Click);
            // 
            // btn_auto_trigger_stop
            // 
            this.btn_auto_trigger_stop.BackColor = System.Drawing.Color.Teal;
            this.btn_auto_trigger_stop.FlatAppearance.BorderSize = 0;
            this.btn_auto_trigger_stop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_auto_trigger_stop.ForeColor = System.Drawing.Color.White;
            this.btn_auto_trigger_stop.Location = new System.Drawing.Point(146, 67);
            this.btn_auto_trigger_stop.Name = "btn_auto_trigger_stop";
            this.btn_auto_trigger_stop.Size = new System.Drawing.Size(150, 40);
            this.btn_auto_trigger_stop.TabIndex = 0;
            this.btn_auto_trigger_stop.Text = "STOP";
            this.btn_auto_trigger_stop.UseVisualStyleBackColor = false;
            this.btn_auto_trigger_stop.Click += new System.EventHandler(this.btn_auto_trigger_stop_Click);
            // 
            // timer_auto_trigger
            // 
            this.timer_auto_trigger.Tick += new System.EventHandler(this.timer_auto_trigger_Tick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_flip_still_Image);
            this.groupBox2.Controls.Add(this.rbtn_flip_XY);
            this.groupBox2.Controls.Add(this.rbtn_flip_X);
            this.groupBox2.Controls.Add(this.rbtn_flip_Y);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(591, 605);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(133, 124);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "FLIP";
            // 
            // btn_camera_reload
            // 
            this.btn_camera_reload.BackColor = System.Drawing.Color.Teal;
            this.btn_camera_reload.FlatAppearance.BorderSize = 0;
            this.btn_camera_reload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_camera_reload.Location = new System.Drawing.Point(319, 15);
            this.btn_camera_reload.Name = "btn_camera_reload";
            this.btn_camera_reload.Size = new System.Drawing.Size(95, 75);
            this.btn_camera_reload.TabIndex = 13;
            this.btn_camera_reload.Text = "CAMERA RELOAD";
            this.btn_camera_reload.UseVisualStyleBackColor = false;
            this.btn_camera_reload.Click += new System.EventHandler(this.btn_camera_reload_Click);
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1803, 733);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox17);
            this.Controls.Add(this.groupBox16);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox15);
            this.Controls.Add(this.txt_msg);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.btn_save_settings);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.label2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frm_main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Test Bench For Image Process";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_main_FormClosing);
            this.Load += new System.EventHandler(this.frm_main_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_still_original)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_still_edit)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_zoom)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbo_video_channel_selection;
        private System.Windows.Forms.Button btn_browse_still_Image;
        private System.Windows.Forms.RadioButton rbtn_video_Image;
        private System.Windows.Forms.RadioButton rbtn_still_Image;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pb_still_original;
        private System.Windows.Forms.PictureBox pb_still_edit;
        private System.Windows.Forms.TextBox txt_still_image_path;
        private System.Windows.Forms.Button btn_save_settings;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txt_erode_size;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button btn_motion_camera_next;
        private System.Windows.Forms.Button btn_motion_camera_previous;
        private System.Windows.Forms.TextBox txt_msg;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button btn_still_img_copy;
        private System.Windows.Forms.Button btn_undo;
        private System.Windows.Forms.Button btn_redo;
        private System.Windows.Forms.Button btn_flip_still_Image;
        private System.Windows.Forms.Button btn_still_gray;
        private System.Windows.Forms.Button btn_save_still_edited;
        private System.Windows.Forms.Button btn_save_still_original;
        private System.Windows.Forms.Timer timer_camera_read;
        private System.Windows.Forms.Timer timer_program_runner;
        private System.Windows.Forms.RadioButton rbtn_flip_XY;
        private System.Windows.Forms.RadioButton rbtn_flip_Y;
        private System.Windows.Forms.RadioButton rbtn_flip_X;
        private System.Windows.Forms.Button btn_erode;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_erode_iteration;
        private System.Windows.Forms.Button btn_dilate;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Button btn_contour_draw;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_contour_thickness;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_contour_threshold;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_Canny_Edge_L1;
        private System.Windows.Forms.Button btn_binary_threshold;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_auto_trigger_min_val;
        private System.Windows.Forms.Button btn_auto_trigger_start;
        private System.Windows.Forms.Button btn_auto_trigger_stop;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_auto_trigger_running_val;
        private System.Windows.Forms.TextBox txt_auto_trigger_max_val;
        private System.Windows.Forms.TextBox txt_auto_trigger_interval;
        private System.Windows.Forms.CheckBox chk_enable_auto_trigger;
        private System.Windows.Forms.Button btn_OTSU;
        private System.Windows.Forms.Button btn_Adaptive_threshold;
        private System.Windows.Forms.Timer timer_auto_trigger;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_auto_trigger_step;
        private System.Windows.Forms.Button btn_Canny_L2;
        private System.Windows.Forms.Button btn_sobel_XY;
        private System.Windows.Forms.Button btn_sobel_Y;
        private System.Windows.Forms.Button btn_sobel_X;
        private System.Windows.Forms.Button btn_Sobel_XY64;
        private System.Windows.Forms.PictureBox pb_zoom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.HScrollBar hs_Zoom;
        private System.Windows.Forms.TextBox txt_zoom_val;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_camera_reload;
    }
}

