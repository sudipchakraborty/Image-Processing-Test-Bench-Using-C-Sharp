﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenCvSharp;
using OpenCvSharp.Extensions;

using Tools;

namespace Test_Bench_For_Image_Process
{
    public partial class frm_main : Form
    {
        project_helper help = new project_helper();
        OpenCvCamera_NonThreaded camN=new OpenCvCamera_NonThreaded();
        Image Still_Image_Edit_BackUp;
        int auto_trigger_running_val;
        Image auto_trigger_Img_BackUp;
        string auto_trigger_command;
        magnifier zoom;
        
        enum auto_trigger
        {
            Binary_threshold,
            Adaptive,
            otsu
        };

        public frm_main()
        {
            InitializeComponent();
            zoom = new magnifier(pb_still_edit,pb_zoom);
         
        }

        private void frm_main_Load(object sender, EventArgs e)
        {
            utilOpenCV.Load_ComboBox_WithConnected_Camera(cbo_video_channel_selection);
            camN.max_camera_count = cbo_video_channel_selection.Items.Count;
            utilOpenCV.set_Edit_ImageBox(ref pb_still_edit);

            help.Load_Settings();
            txt_still_image_path.Text = help.set_still_image_path;

            camN.camera_index = utilOpenCV.Update_Camera_Index(cbo_video_channel_selection,help.set_video_channel);


            if (help.set_Image_Type == project_helper.image_type.still.ToString()) rbtn_still_Image.Checked = true;
            if (help.set_Image_Type == project_helper.image_type.video.ToString()) rbtn_video_Image.Checked = true;


            if (rbtn_still_Image.Checked == true)
            {
                utilOpenCV.Load_Image_To_PictureBox(pb_still_original, txt_still_image_path.Text);
            }

            if(rbtn_video_Image.Checked == true)
            {
                timer_camera_read.Interval = 1;
                camN.open();
                timer_camera_read.Start();
            }

            this.Size = new System.Drawing.Size(1819, 772);
            //   frm_main.Width = 1900;
            //  this.Size.Height = 

           
        }

        private void btn_browse_still_Image_Click(object sender, EventArgs e)
        {
            string f_name = UtilFile.Get_File_Name_From_DialogBox();
            if (f_name != "")
            {
                help.set_still_image_path = f_name;
                pb_still_original.Image = Image.FromFile(f_name);
            }

        }

        private void frm_main_FormClosing(object sender, FormClosingEventArgs e)
        {
            help.Save_Settings();
        }

        private void btn_save_settings_Click(object sender, EventArgs e)
        {
            help.Save_Settings();
        }

        private void rbtn_still_Image_CheckedChanged(object sender, EventArgs e)
        {
            help.set_Image_Type = project_helper.image_type.still.ToString();
            if (rbtn_still_Image.Checked == true)
            {
                timer_camera_read.Stop();
                camN.close();
                utilOpenCV.Load_Image_To_PictureBox(pb_still_original, txt_still_image_path.Text);
            }

        }
  
        private void rbtn_video_Image_CheckedChanged(object sender, EventArgs e)
        {
            help.set_video_channel = cbo_video_channel_selection.Text;
            camN.camera_index = utilOpenCV.Update_Camera_Index(cbo_video_channel_selection, help.set_video_channel);
            help.set_Image_Type = project_helper.image_type.video.ToString();  
            timer_camera_read.Interval = 1;
            camN.open();
            timer_camera_read.Start();
        }

        private void btn_clone_Click(object sender, EventArgs e)
        {
            Mat mat = new Mat(30, 40, MatType.CV_8UC3, new Scalar(0, 255, 255));
            Cv2.ImShow("sss", mat);
            utilOpenCV.cam_index++;
            if (utilOpenCV.cam_index > 2) utilOpenCV.cam_index = 0;

            // utilOpenCV.Copy_Image(pb_still_original, pb_still_edit);
        }

        private void btn_motion_camera_open_Click(object sender, EventArgs e)
        {
            if (camN.IsOpened)
            {
                txt_msg.Text="Already Opened";
                return;
            }
  
            camN = new OpenCvCamera_NonThreaded();
            camN.open();

            if (camN.IsOpened)
            {
                txt_msg.Text = "Camera Opened OK";
            }
            else
            {
                txt_msg.Text = "Unable to Open the Camera";
            }

        }

        private void btn_motion_camera_close_Click(object sender, EventArgs e)
        {
            camN.close();
        }

        private void btn_motion_camera_start_Click(object sender, EventArgs e)
        {
           timer_camera_read.Interval = 1;
           timer_camera_read.Enabled = true;
        }

        private void btn_motion_camera_stop_Click(object sender, EventArgs e)
        {
            timer_camera_read.Enabled = false;
        }

        private void btn_motion_camera_previous_Click(object sender, EventArgs e)
        {
            //cam.previous();
        }

        private void btn_motion_camera_next_Click(object sender, EventArgs e)
        {
            camN.Get_next_Camera_Image();
        }

        private void btn_still_img_copy_Click(object sender, EventArgs e)
        {
            pb_still_edit.Image = pb_still_original.Image;

        }

        private void btn_still_gray_Click(object sender, EventArgs e)
        {
            utilOpenCV.Convert_to_Gray_Image(pb_still_edit);
        }

        private void btn_Copy_Video_Click(object sender, EventArgs e)
        {
           // pb_still_original.Image = pb_camera_original.Image;
        }

        private void btn_save_still_original_Click(object sender, EventArgs e)
        {
            UtilFile.Save_PictureBox(pb_still_original);
        }

        private void btn_flip_still_Image_Click(object sender, EventArgs e)
        {
            utilOpenCV.flip_Image(rbtn_flip_X, rbtn_flip_Y, rbtn_flip_XY, pb_still_edit);
        }

        private void btn_prog_start_Click(object sender, EventArgs e)
        {
            camN = new OpenCvCamera_NonThreaded();
           
            timer_camera_read.Interval=1;
            timer_camera_read.Enabled = true;
        }

        private void timer_camera_read_Tick(object sender, EventArgs e)
        {
            pb_still_original.Image = camN.Get_Image();
        }

        private void btn_erode_Click(object sender, EventArgs e)
        {
            pb_still_edit.Image = utilOpenCV.erode(pb_still_edit,txt_erode_iteration.Text,txt_erode_size.Text);
        }

        private void btn_dilate_Click(object sender, EventArgs e)
        {
            pb_still_edit.Image = utilOpenCV.dilate(pb_still_edit, txt_erode_iteration.Text, txt_erode_size.Text);
        }

        private void btn_contour_draw_Click(object sender, EventArgs e)
        {
            pb_still_edit.Image = utilOpenCV.contour_draw(pb_still_edit, txt_contour_thickness.Text, txt_contour_threshold.Text);
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            utilOpenCV.contour_find();
        }

        private void btn_binary_threshold_Click(object sender, EventArgs e)
        {
            auto_trigger_Img_BackUp=pb_still_edit.Image;
            auto_trigger_command = auto_trigger.Binary_threshold.ToString();
            timer_auto_trigger.Interval = Convert.ToInt16(txt_auto_trigger_interval.Text);
            timer_auto_trigger.Enabled = true;
        }

        private void btn_auto_trigger_start_Click(object sender, EventArgs e)
        {
            if(chk_enable_auto_trigger.Checked)
            {
                timer_auto_trigger.Enabled = true;
            }
        }

        private void btn_auto_trigger_stop_Click(object sender, EventArgs e)
        {
            timer_auto_trigger.Enabled = false;
        }

        private void timer_auto_trigger_Tick(object sender, EventArgs e)
        {
            pb_still_edit.Image = auto_trigger_Img_BackUp;

            switch (auto_trigger_command)
            {
                case "Binary_threshold":
                    utilOpenCV.Get_threshold_Image(ref pb_still_edit, Convert.ToInt16(txt_auto_trigger_running_val.Text));
                    break;
                /////////////////
                case "Adaptive":
                    utilOpenCV.Adaptive_threshold(ref pb_still_edit, Convert.ToInt16(txt_auto_trigger_running_val.Text));
                    break;

                case "otsu":
                    utilOpenCV.OTSU_threshold(ref pb_still_edit, Convert.ToInt16(txt_auto_trigger_running_val.Text));

                    break;

                default:
                    break;



            }


            int trig_step = Convert.ToInt16(txt_auto_trigger_step.Text);
            int running_val= Convert.ToInt16(txt_auto_trigger_running_val.Text);
            int max_val = Convert.ToInt16(txt_auto_trigger_max_val.Text);
            if (running_val < max_val)
            {
                running_val += trig_step;
                txt_auto_trigger_running_val.Text=running_val.ToString();
            }
            else
            {
                txt_auto_trigger_running_val.Text = txt_auto_trigger_min_val.Text;
            }

            if (!chk_enable_auto_trigger.Checked) timer_auto_trigger.Enabled = false;
            

        }

        private void btn_Adaptive_threshold_Click(object sender, EventArgs e)
        {
            auto_trigger_Img_BackUp = pb_still_edit.Image;
            auto_trigger_command = auto_trigger.Adaptive.ToString();
            timer_auto_trigger.Interval = Convert.ToInt16(txt_auto_trigger_interval.Text);
            timer_auto_trigger.Enabled = true;
        }

        private void btn_OTSU_Click(object sender, EventArgs e)
        {
            auto_trigger_Img_BackUp = pb_still_edit.Image;
            auto_trigger_command = auto_trigger.otsu.ToString();
            timer_auto_trigger.Interval = Convert.ToInt16(txt_auto_trigger_interval.Text);
            timer_auto_trigger.Enabled = true;
        }

        private void btn_Canny_Edge_L1_Click(object sender, EventArgs e)
        {
            utilOpenCV.Canny_Edge_L1(0);
        }

        private void btn_Canny_L2_Click(object sender, EventArgs e)
        {
            utilOpenCV.Canny_Edge_L2(0);
        }

        private void btn_sobel_X_Click(object sender, EventArgs e)
        {
            utilOpenCV.sobel_X();
        }

        private void btn_sobel_Y_Click(object sender, EventArgs e)
        {
            utilOpenCV.sobel_Y();
        }

        private void btn_sobel_XY_Click(object sender, EventArgs e)
        {
            utilOpenCV.sobel_XY();
        }

        private void btn_Sobel_XY64_Click(object sender, EventArgs e)
        {
            utilOpenCV.sobel_XY64();
        }

        private void pb_zoom_MouseMove(object sender, MouseEventArgs e)
        {
            
        }

        private void pb_still_edit_MouseMove(object sender, MouseEventArgs e)
        {
            zoom.UpdateZoomedImage(e, hs_Zoom.Value);
        }

        private void hs_Zoom_Scroll(object sender, ScrollEventArgs e)
        {
            txt_zoom_val.Text = hs_Zoom.Value.ToString();
        }

        private void cbo_video_channel_selection_SelectedIndexChanged(object sender, EventArgs e)
        {
            help.set_video_channel = cbo_video_channel_selection.Text;
            camN.camera_index = utilOpenCV.Update_Camera_Index(cbo_video_channel_selection, help.set_video_channel);
            timer_camera_read.Interval = 1;
            camN.close();
            camN.open();
            timer_camera_read.Start();
        }

        private void rbtn_flip_X_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void rbtn_flip_Y_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtn_flip_XY_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btn_camera_reload_Click(object sender, EventArgs e)
        {
            utilOpenCV.Load_ComboBox_WithConnected_Camera(cbo_video_channel_selection);
            camN.max_camera_count = cbo_video_channel_selection.Items.Count;
        }

        private void btn_save_still_edited_Click(object sender, EventArgs e)
        {

        }
    }// class
}// Namespace
