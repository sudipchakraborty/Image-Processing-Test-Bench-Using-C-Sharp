﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web; 
using System.IO; // for File operation 
using Json.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
/// <summary>
/// //////////////////////////////////////////////////////////////////////////////////////////////
/// </summary>

// from Nuget install "Newtonsoft.Json" and "Json.Net" 

namespace Tools
{
   public class json_handler
    {
        string file_name = "";
        //_____________________________________________________________________________________________________
        public json_handler (string file_name)
        {
            this.file_name = file_name;
        }
        //______________________________________________________________________________________________________
        public string Get(string param)
        {
            if (file_name == "") return "";
            string readResult = string.Empty;
            using (StreamReader r = new StreamReader(file_name))
            {
                var json = r.ReadToEnd();
                var jobj = JObject.Parse(json);
                readResult = jobj.ToString();
                foreach (var item in jobj.Properties())
                {
                    string prm = item.Name;
                    string val = item.Value.ToString();
                    if(prm==param)
                    {
                        return val;
                    }                   
                }
            }
            return "";
        }
        //___________________________________________________________________________________________________
        public void put(string param, string value)
        {
            if (file_name == "") return;

            string readResult = string.Empty;
            string writeResult = string.Empty;
            using (StreamReader r = new StreamReader(file_name))
            {
                var json = r.ReadToEnd();
                var jobj = JObject.Parse(json);
                readResult = jobj.ToString();
                foreach (var item in jobj.Properties())
                {
                    string prm = item.Name;
                    if(prm==param)
                    {
                        item.Value = value;
                    }
                }
                writeResult = jobj.ToString();
            }
            File.WriteAllText(file_name, writeResult);
        }
        //___________________________________________________________________________________________________
        public void update(string prev, string current) 
        {
            if (file_name == "") return;

            string readResult = string.Empty;
            string writeResult = string.Empty;
            using (StreamReader r = new StreamReader(file_name))
            {
                var json = r.ReadToEnd();
                var jobj = JObject.Parse(json);
                readResult = jobj.ToString();
                foreach (var item in jobj.Properties())
                {
                    item.Value = item.Value.ToString().Replace(prev, current);
                }
                writeResult = jobj.ToString();
            }
            File.WriteAllText(file_name, writeResult);             
        }
        //___________________________________________________________________________________________________
    }
}
