﻿using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tools
{
    public class magnifier
    {
        PictureBox pb_src=new PictureBox();
        PictureBox pb_zoom = new PictureBox();

        public int ZoomFactor = 1;
        public Color BackColor = new Color();

        public magnifier(PictureBox src,PictureBox zoom)
        {
            pb_src= src;
            pb_zoom= zoom;
            BackColor = Color.Black;
        }

        public void UpdateZoomedImage(MouseEventArgs e, int zoom_factor)
        {
            if (pb_src.Image == null) return;
            this.ZoomFactor = zoom_factor;

            int zoomWidth = pb_src.Width / ZoomFactor;
            int zoomHeight = pb_src.Height / ZoomFactor;

            int halfWidth = zoomWidth / 2;
            int halfHeight = zoomHeight / 2;

            Bitmap tempBitmap = new Bitmap(zoomWidth, zoomHeight, PixelFormat.Format24bppRgb);

            Graphics bmGraphics = Graphics.FromImage(tempBitmap);
            bmGraphics.Clear(BackColor);
            bmGraphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            bmGraphics.DrawImage(pb_src.Image,
                                 new Rectangle(0, 0, zoomWidth, zoomHeight),
                                 new Rectangle(e.X - halfWidth, e.Y - halfHeight, zoomWidth, zoomHeight),
                                 GraphicsUnit.Pixel);

            pb_zoom.Image = tempBitmap;

            // Draw a crosshair on the bitmap to simulate the cursor position
            bmGraphics.DrawLine(Pens.Black, halfWidth + 1, halfHeight - 4, halfWidth + 1, halfHeight - 1);
            bmGraphics.DrawLine(Pens.Black, halfWidth + 1, halfHeight + 6, halfWidth + 1, halfHeight + 3);
            bmGraphics.DrawLine(Pens.Black, halfWidth - 4, halfHeight + 1, halfWidth - 1, halfHeight + 1);
            bmGraphics.DrawLine(Pens.Black, halfWidth + 6, halfHeight + 1, halfWidth + 3, halfHeight + 1);

            // Dispose of the Graphics object
            bmGraphics.Dispose();
            pb_zoom.Refresh();
        }




























    }// class
}// Namespace
