﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Tools;

namespace Test_Bench_For_Image_Process
{
    internal class project_helper
    {
       public enum image_type
        {
            still,
            video
        }

        json_handler mem = new json_handler("settings.json");

        public string set_Image_Type;
        public string set_still_image_path;
        public string set_video_channel;
       
        public void Load_Settings()
        {
            set_Image_Type = mem.Get("Image_Type");
            set_still_image_path = mem.Get("still_image_path");
            set_video_channel = mem.Get("video_channel");
        }

        public void Save_Settings()
        {
            mem.put("Image_Type", set_Image_Type);
            mem.put("still_image_path", set_still_image_path);
            mem.put("video_channel", set_video_channel);
        }

      
       























    
    
    }// class
}// namespace
