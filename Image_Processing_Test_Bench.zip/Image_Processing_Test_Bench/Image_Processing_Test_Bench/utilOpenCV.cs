﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenCvSharp;
using OpenCvSharp.Extensions;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.CompilerServices;
using OpenCvSharp;
using System.Management;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

// from Nuget install "System.Management"

namespace Tools
{
   public static class utilOpenCV
    {
       static VideoCapture capture;
       static OpenCvSharp.Mat frame;
       static Bitmap image;
       static Thread camera;
       static bool isCameraRunning = false;

       public static int cam_index = 0; 
       static Mat temp = new Mat();
       public static PictureBox    pb_edit=new PictureBox();
             
        public static void set_Edit_ImageBox(ref  PictureBox pb)
        {
            pb_edit = pb;   
        }

       // public static void cam(PictureBox pb1)
       // {
       //     pb = new PictureBox();
       //     pb = pb1;
            
       //     camera = new Thread(new ThreadStart(CaptureCameraCallback));
       //     camera.Start();
       // }
       // /// <summary>
       // /// ///////////////////////
       // /// </summary>
       // private static void CaptureCameraCallback()
       // {
       //     frame = new OpenCvSharp.Mat();
       //     capture = new VideoCapture(cam_index);
       //     capture.Open(cam_index);
       ////     capture.Dispose();

       //     if (capture.IsOpened())
       //     {
       //         isCameraRunning = true;
       //         while (isCameraRunning)
       //         {
       //             capture.Read(frame);
       //             image = BitmapConverter.ToBitmap(frame);
       //             if (pb.Image != null)
       //             {
       //                 pb.Image.Dispose();
       //             }
       //             pb.Image = image;
       //         }
       //     }
       // }

        public static void Load_Image_To_PictureBox(PictureBox pb, string f_name)
        {
            OpenCvSharp.Mat c_Image = Cv2.ImRead(f_name, ImreadModes.Color);
            Image img = BitmapConverter.ToBitmap(c_Image);
            pb.Image = img;
        }

        public static void Load_Gray_Image_To_PictureBox(PictureBox pb, string f_name)
        {
            OpenCvSharp.Mat c_Image = Cv2.ImRead(f_name, ImreadModes.Grayscale);
            Image img = BitmapConverter.ToBitmap(c_Image);
            pb.Image = img;
        }

        public static Mat Get_Mat(PictureBox pb)
        {
            OpenCvSharp.Mat c_Image = BitmapConverter.ToMat((Bitmap)pb.Image);
            return c_Image;
        }

        public static Image Get_Image(Mat img)
        {
            Image ret_img = BitmapConverter.ToBitmap(img); 
            return ret_img;
        }

        public static void Convert_to_Gray_Image(PictureBox pb)
        {
            try
            {
                OpenCvSharp.Mat c_Image = BitmapConverter.ToMat((Bitmap)pb.Image);
                Mat grayscale = c_Image.CvtColor(ColorConversionCodes.BGR2GRAY);
                Image img = BitmapConverter.ToBitmap(grayscale);
                pb.Image = img;
            }catch(Exception ex)
            {

            }
        }

        public static void split_channel(PictureBox pb, string f_name)
        {
            OpenCvSharp.Mat c_Image = Cv2.ImRead(f_name, ImreadModes.Grayscale);
            Image img = BitmapConverter.ToBitmap(c_Image);
            
            pb.Image = img;
            // omez 20

            Mat[] channels;
            Cv2.Split(c_Image, out channels);
            Cv2.ImShow("blue", channels[0]);
            ///////////
            Mat ROImage = new Mat(c_Image, new Rect(50, 50, 250, 250));
            Cv2.ImShow("ROI", ROImage);
            //////////////////
            int numRows = c_Image.Rows;
            int numCols = c_Image.Cols;
            for (int y = 0; y < numRows; y++)
            {
                for (int x = 0; x < numCols; x++)
                {
                    Vec3b pixel = c_Image.Get<Vec3b>(y, x);
                    byte blue = pixel.Item0;
                    byte green = pixel.Item1;
                    byte red = pixel.Item2;
                    byte temp = blue;
                    pixel.Item0 = red;
                    pixel.Item2 = temp;
                    c_Image.Set<Vec3b> (y, x, pixel);
                }
            }
            Cv2.ImShow("Swaped",c_Image);
            //////////////////////////////////////////
            var indexer=c_Image.GetGenericIndexer<Vec3b>();
            for (int y = 0; y < numRows; y++)
            {
                for (int x = 0; x < numCols; x++)
                {
                    Vec3b pixel = indexer[y,x];
                    byte blue = pixel.Item0;
                    byte green = pixel.Item1;
                    byte red = pixel.Item2;
                    byte temp = blue;
                    pixel.Item0 = red;
                    pixel.Item2 = temp;
                    indexer[y, x] = pixel;
                }
            }
            Cv2.ImShow("Swaped", c_Image);
            //////////////////////////////////////////

















        }

        public static void Copy_Image_Colour(PictureBox src_pb, PictureBox dst_pb)
        {         
            OpenCvSharp.Mat c_Image = BitmapConverter.ToMat((Bitmap)src_pb.Image);
            Image img = BitmapConverter.ToBitmap(c_Image);
            dst_pb.Image = img;
        }

        public static void Copy_Image_Gray(PictureBox src_pb, PictureBox dst_pb)
        {

            Mat mat = new Mat(30, 40, MatType.CV_8UC3, new Scalar(0, 0, 255));
            Cv2.ImShow("sss", mat);

            //OpenCvSharp.Mat c_Image = BitmapConverter.ToMat((Bitmap)src_pb.Image);

            //OpenCvSharp.Mat grayscale = Cv2.CvtColor(image, c_Image, OpenCvSharp.Cv2.CvtColor());

            //Image img = BitmapConverter.ToBitmap(c_Image);
            //dst_pb.Image = img;

//            import cv2
//image = cv2.imread('colourful.jpg')
//cv2.imshow('Original', image)
//grayscale = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
//cv2.imshow('Grayscale', grayscale)


        }

        public static void hellow_drawing()
        {
            OpenCvSharp.Mat mat = new OpenCvSharp.Mat(30, 40, MatType.CV_8UC3, new Scalar(0, 0, 255));
            OpenCvSharp.Mat mat1 = new OpenCvSharp.Mat(new OpenCvSharp.Size(30, 40), MatType.CV_8UC3, new Scalar(0, 0, 255));

            Cv2.ImShow("m", mat);
            Cv2.ImShow("m1", mat1);
            Cv2.WaitKey();
            Cv2.DestroyAllWindows();
        }

        public static void show_Image()
        {
            string path = @"..\..\..\lena.jpg";
            OpenCvSharp.Mat colorImage = Cv2.ImRead(path, ImreadModes.Color);
            Cv2.ImShow("original", colorImage);

            OpenCvSharp.Mat clonedImage = colorImage.Clone();
            Cv2.ImShow("cloned", clonedImage);

            OpenCvSharp.Mat anotherClonedImage = new OpenCvSharp.Mat();
            colorImage.CopyTo(anotherClonedImage);
            Cv2.ImShow("another cloned", anotherClonedImage);

            Cv2.WaitKey();
            Cv2.DestroyAllWindows();
        }

        public static void Load_ComboBox_WithConnected_Camera(System.Windows.Forms.ComboBox cb)
        {
            List<string> lst = GetAllConnectedCameras();
            cb.Items.Clear();
            cb.DataSource = lst;

        }

        public static List<string> GetAllConnectedCameras()
        {
            var cameraNames = new List<string>();
            using (var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE (PNPClass = 'Image' OR PNPClass = 'Camera')"))
            {
                foreach (var device in searcher.Get())
                {
                    cameraNames.Add(device["Caption"].ToString());
                }
            }

            return cameraNames;
        }

        public static int Update_Camera_Index(System.Windows.Forms.ComboBox cb, string Camera_Name)
        {
            if (cb.Items.Count <= 0) return 0;
            for (int i = 0; i < cb.Items.Count; i++)
            {
                string value = cb.GetItemText(cb.Items[i]);
                if (value == Camera_Name)
                {
                    cb.SelectedIndex = i;
                    return i;
                }
            }
            return 0;
        }

        public static void contour_find()
        {
            OpenCvSharp.Mat img1 = Cv2.ImRead(@"G:\\My Drive\\PAPER Publish\\3. RUNNING\\9) Image_Processing_Test_Bench_Using_C#\\Test_Image\\boomerang.png");
            OpenCvSharp.Mat img2 = Cv2.ImRead(@"G:\\My Drive\\PAPER Publish\\3. RUNNING\\9) Image_Processing_Test_Bench_Using_C#\\Test_Image\\shapes.png");

            var refContour = GetRefContour(img1);
            var inputContours = GetAllContours(img2);

            OpenCvSharp.Point[] closestContour = null;

            double minDist = 0.0;
            OpenCvSharp.Mat contourImg = img2.Clone();

            Cv2.ImShow("Contours", img2);
            Cv2.ImShow("ref", img1);

            int i = 0;
            foreach (var contour in inputContours)
            {
                double ret = Cv2.MatchShapes(refContour, contour, ShapeMatchModes.I3);
                if (minDist == 0.0 | ret < minDist)
                {
                    minDist = ret;
                    closestContour = contour;
                }
                i++;
            }

            Cv2.DrawContours(img2, new OpenCvSharp.Point[][] { closestContour }, 0, new Scalar(0, 0, 0), thickness: 3);
            Cv2.ImShow("Best Matching", img2);
        }

      public static OpenCvSharp.Point[] GetRefContour(OpenCvSharp.Mat img)
        {
            var contours = GetAllContours(img);
            //Extract the relevant contour based on area ratio. We use the
            //area ratio because the main image boundary contour is
            //extracted as well and we don't want that. This area ratio
            // limit will ensure that we only take the contour inside the image.
            foreach (var contour in contours)
            {
                var area = Cv2.ContourArea(contour);
                var imgArea = img.Width * img.Height;
                var ratio = area / (float)imgArea;
                if (ratio > 0.10 && ratio < 0.8)
                    return contour;
            }
            return null;
        }

        public static void flip_Image(RadioButton X,RadioButton Y, RadioButton XY, PictureBox pb)
        {
            try
            {
                OpenCvSharp.Mat c_Image = BitmapConverter.ToMat((Bitmap)pb.Image);
                if (X.Checked) Cv2.Flip(c_Image, c_Image, FlipMode.X);
                if (Y.Checked) Cv2.Flip(c_Image, c_Image, FlipMode.Y);
                if (XY.Checked) Cv2.Flip(c_Image, c_Image, FlipMode.XY);
                pb.Image = BitmapConverter.ToBitmap(c_Image);
            }catch (Exception ex)
            {

            }
        }

        public static void flip_Image(string dir, PictureBox pb)
        {
            OpenCvSharp.Mat c_Image = BitmapConverter.ToMat((Bitmap)pb.Image);                      
            if(dir=="X")        Cv2.Flip(c_Image, c_Image, FlipMode.X);
            if(dir == "Y")      Cv2.Flip(c_Image, c_Image, FlipMode.Y);
            if(dir == "XY")     Cv2.Flip(c_Image, c_Image, FlipMode.XY);
            pb.Image = BitmapConverter.ToBitmap(c_Image);                    
        }

        public static Image erode(PictureBox pb, string itr,string sz)
        {
            OpenCvSharp.Mat src = Get_Mat(pb);    
            OpenCvSharp.Mat kernel = Cv2.GetStructuringElement(MorphShapes.Rect, new OpenCvSharp.Size(Convert.ToInt16(sz), Convert.ToInt16(sz)));
            OpenCvSharp.Mat img_erode = new OpenCvSharp.Mat();

            Cv2.Erode(src, img_erode, kernel, iterations: Convert.ToInt16(itr));
            return Get_Image(img_erode);

        }

        public static Image dilate(PictureBox pb, string itr, string sz)
        {
            OpenCvSharp.Mat src = Get_Mat(pb);
            OpenCvSharp.Mat kernel = Cv2.GetStructuringElement(MorphShapes.Rect, new OpenCvSharp.Size(Convert.ToInt16(sz), Convert.ToInt16(sz)));
            OpenCvSharp.Mat img_dilate = new OpenCvSharp.Mat();

            Cv2.Dilate(src, img_dilate, kernel, iterations: Convert.ToInt16(itr));
            return Get_Image(img_dilate);
        }

        public static Image contour_draw(PictureBox pb, string thickness, string thresh_val)
        {
            Mat image = Get_Mat(pb);

            OpenCvSharp.Point[][] contours = GetAllContours(image, Convert.ToInt16(thresh_val));
          
            Cv2.DrawContours(image, contours, -1, new Scalar(0, 0, 0), thickness: Convert.ToInt16(thickness));
            return Get_Image(image);
        }
        //_____________________________________________________________________________________________________
        public static OpenCvSharp.Point[][] GetAllContours(Mat img)
        {
            Mat refGray=new Mat();
            Cv2.CvtColor(img,refGray,ColorConversionCodes.BGR2GRAY);

            Mat thresh = new Mat();
            Cv2.Threshold(refGray, thresh, 127, 255, ThresholdTypes.Binary);

            OpenCvSharp.Point[][] contours;
            HierarchyIndex[] hindex;
            Cv2.FindContours(thresh, out contours, out hindex, RetrievalModes.List, ContourApproximationModes.ApproxSimple);

            return contours;
        }
        //_____________________________________________________________________________________________________

        public static OpenCvSharp.Point[][] GetAllContours(OpenCvSharp.Mat img,int thresh_val)
        {
            OpenCvSharp.Mat thresh = new OpenCvSharp.Mat();
            Cv2.Threshold(img, thresh, thresh_val, 255, ThresholdTypes.Binary);

            OpenCvSharp.Point[][] contours;
            HierarchyIndex[] hindex;
            Cv2.FindContours(thresh, out contours, out hindex, RetrievalModes.List, ContourApproximationModes.ApproxSimple);

            return contours;
        }
       
        public static void Canny_Edge_L1(int th_val)
        {          
            Cv2.Canny(Get_Mat(pb_edit), temp, 125, 350, 3, false);
            pb_edit.Image=Get_Image(temp);
        }

        public static void Canny_Edge_L2(int th_val)
        {
            Cv2.Canny(Get_Mat(pb_edit), temp, 125, 350, 3, true);
            pb_edit.Image = Get_Image(temp);
        }

        public static void OTSU_threshold(ref PictureBox pb, int th_val)
        {
            Mat otsu = new Mat();
            Cv2.Threshold(Get_Mat(pb), otsu, th_val, 255, ThresholdTypes.Otsu | ThresholdTypes.Binary);
            pb.Image = Get_Image(otsu);
            otsu.Dispose();
        }
  
        public static void Adaptive_threshold(ref PictureBox pb, int th_val)
        {
            Mat adaptive = new Mat();
            Cv2.AdaptiveThreshold(Get_Mat(pb), adaptive, 255, AdaptiveThresholdTypes.GaussianC, ThresholdTypes.Binary, 11, 1.0);
            pb.Image = Get_Image(adaptive);
            adaptive.Dispose();
        }

        public static void Get_threshold_Image(ref PictureBox pb, int th_val)
        {
            Mat image=Get_Mat(pb);
            Mat threshold = new Mat(new OpenCvSharp.Size(image.Width, image.Height), MatType.CV_8UC3, new Scalar(0));
            Cv2.Threshold(image, threshold,th_val, 255, ThresholdTypes.Binary);
            image.Dispose();
            pb.Image =Get_Image(threshold);
            image.Dispose();
            threshold.Dispose();
        }

        public static void sobel_X() 
        {
            int ksize = 3;
            temp = Get_Mat(pb_edit);
            Cv2.Sobel(Get_Mat(pb_edit), temp, MatType.CV_8U, 1, 0, ksize);
            pb_edit.Image=Get_Image(temp);
        }

        public static void sobel_Y()
        {
            int ksize = 3;
            temp = Get_Mat(pb_edit);
            Cv2.Sobel(Get_Mat(pb_edit), temp, MatType.CV_8U, 0, 1, ksize);
            pb_edit.Image = Get_Image(temp);
        }

        public static void sobel_XY()
        {
            int ksize = 3;
            temp=Get_Mat(pb_edit);

            Mat sobelX = new Mat(temp.Rows, temp.Cols, MatType.CV_8U);
            Mat sobelY = new Mat(temp.Rows, temp.Cols, MatType.CV_8U);

            Cv2.Sobel(temp, sobelX, MatType.CV_8U, 1, 0, ksize);
            Cv2.Sobel(temp, sobelY, MatType.CV_8U, 0, 1, ksize);

            Mat sobelXY = new Mat();
            Cv2.Add(sobelX, sobelY, sobelXY);

            pb_edit.Image = Get_Image(sobelXY);

        }

        public static void sobel_XY64() 
        {
            int ksize = 3;
            temp = Get_Mat(pb_edit);

            Mat sobelX64 = new Mat(temp.Rows, temp.Cols, MatType.CV_64F);
            Mat sobelY64 = new Mat(temp.Rows, temp.Cols, MatType.CV_64F);
            Mat sobelXY64 = new Mat();

            Cv2.Sobel(temp, sobelX64, MatType.CV_64F, 1, 0, ksize);
            Cv2.Sobel(temp, sobelY64, MatType.CV_64F, 0, 1, ksize);
 
            Cv2.ConvertScaleAbs(sobelX64, sobelX64);
            Cv2.ConvertScaleAbs(sobelY64, sobelY64);
            Cv2.Add(sobelX64, sobelY64, sobelXY64);
            pb_edit.Image = Get_Image(sobelXY64);

            sobelX64.Dispose();
            sobelY64.Dispose();
            sobelXY64.Dispose();
        }
       






    }// class
}// NameSpace
